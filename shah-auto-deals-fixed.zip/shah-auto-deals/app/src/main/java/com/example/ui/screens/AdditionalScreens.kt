package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdditionalScreen(
    pageName: String,
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(pageName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (pageName) {
                "About Us" -> AboutUsSection()
                "Contact Us" -> ContactUsSection(viewModel)
                "Privacy Policy" -> PrivacyPolicySection()
                "Terms" -> TermsSection()
                "FAQ" -> FaqHelpSection()
                else -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Page not found")
                    }
                }
            }
        }
    }
}

@Composable
fun AboutUsSection() {
    Column {
        Text(
            text = "Shah Auto Deals",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Pakistan's Premier Trusted Auto Marketplace",
            fontSize = 12.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Established in 2024, Shah Auto Deals has quickly grown to become Pakistan’s trusted digital destination for buy, sale, trade, and review of automobiles.\n\nOur mission is to simplify the automotive trading experience for millions of Pakistanis by delivering absolute pricing transparency, highly accurate specifications tables, verified contact details, and robust security parameters against fraudulent behaviors.\n\nWhether you are locating a fuel-efficient Suzuki hatchback for Lahore inner-city traffic, a premium Honda/Toyota sedan for GT Road highway tours, high-performance heavy bikes, or original imported spare auto accessories, Shah Auto Deals provides a fully moderated, streamlined user experience that makes trading frictionless.",
            fontSize = 13.sp,
            lineHeight = 18.sp,
            textAlign = TextAlign.Justify,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))
        Text("Our Core Pillars", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        val pillars = listOf(
            Icons.Default.VerifiedUser to "Anti-Fraud Verification" to "Every reported ad is inspected instantly by admin to guarantee safe, verified auto data.",
            Icons.Default.TrendingUp to "Dynamic Listing Boost" to "Allowing local dealers to highlight inventories easily for faster turnover.",
            Icons.Default.FavoriteBorder to "Customer-First Interface" to "Equipping buyers with instant direct WhatsApp launchers, dialers, and local notifications."
        )

        pillars.forEach { (pair, desc) ->
            val icon = pair.first
            val title = pair.second
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = icon, contentDescription = "", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(desc, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun ContactUsSection(viewModel: AppViewModel) {
    var cName by remember { mutableStateOf("") }
    var cEmail by remember { mutableStateOf("") }
    var cMessage by remember { mutableStateOf("") }

    Column {
        Text("Get In Touch", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Have any queries, legal notices, or feedback? Write to our support division in Lahore.", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = cName,
            onValueChange = { cName = it },
            label = { Text("Your Name") },
            modifier = Modifier.fillMaxWidth().testTag("contact_name_input"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = cEmail,
            onValueChange = { cEmail = it },
            label = { Text("Email Address") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = cMessage,
            onValueChange = { cMessage = it },
            label = { Text("Your Query / Feedback message") },
            modifier = Modifier.fillMaxWidth().height(120.dp),
            maxLines = 5
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (cName.isNotBlank() && cEmail.isNotBlank() && cMessage.isNotBlank()) {
                    viewModel.triggerToast("Thank you! Your message has been received. Our team will email you soon.")
                    cName = ""
                    cEmail = ""
                    cMessage = ""
                } else {
                    viewModel.triggerToast("Please fill all contact fields.")
                }
            },
            modifier = Modifier.fillMaxWidth().height(46.dp).testTag("contact_submit_button"),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Submit Feedback Form", color = Color.White)
        }

        Spacer(modifier = Modifier.height(30.dp))
        Text("Office Headquarters:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Shah Auto Deals Building, 42-A Block H, Gulberg III, Lahore, Punjab, Pakistan.\nEmail: support@shahautodeals.com\nPhone: 042-35712345",
            fontSize = 12.sp,
            color = Color.Gray,
            lineHeight = 16.sp
        )
    }
}

@Composable
fun PrivacyPolicySection() {
    Column {
        Text("Privacy Policy", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Last Modified: May 31, 2026", fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        val rules = listOf(
            "1. Data Collection" to "We gather secure login tokens, emails, phone numbers, and profile avatars solely to register you as a legitimate seller or buyer on Shah Auto Deals platform.",
            "2. Contact Disclosure" to "To streamline buyer-seller interactions, your specified phone number is made visible under published listings to facilitate direct cellular phone calls and active API WhatsApp communication.",
            "3. Location and Maps" to "City-level details are stored dynamically within our local Room SQLite database to support location-based searches, filter listings, and display approximate localization on our custom maps representation.",
            "4. Anti-Fraud Data Logs" to "Report details, spam allegations, and user ratings are strictly analyzed by platform administrators to ban accounts engaging in listing duplications, counterfeit pricing structures, or scam actions."
        )

        rules.forEach { (title, text) ->
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
fun TermsSection() {
    Column {
        Text("Terms & Conditions of Use", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Please read these regulations carefully before uploading advertisements.", fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        val terms = listOf(
            "1. Listing Validity" to "All advertisements posted must carry genuine vehicles currently within the owner's legal possession inside Pakistan territory. Uploading copyrighted internet catalog photos of vehicles you do not own is strictly forbidden.",
            "2. Pricing Policy" to "Specifying misleading pricing triggers manual rejection by administrators. Avoid entering zero or arbitrary low PKR figures to bypass listings order sorting.",
            "3. User Limits & bans" to "Platform administrators possess absolute authority to block accounts, delete reported listings, or flag contacts. Advance payment scams without physical inspection of vehicles will lead to immediate account bans and deletion.",
            "4. Service Indemnity" to "Shah Auto Deals operates purely as a public directory and digital classifieds. The platform is not an agent, middleman, or broker, and bears no responsibility for physical vehicle transaction risks or financial fraud of individual sellers."
        )

        terms.forEach { (title, text) ->
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaqHelpSection() {
    Column {
        Text("Frequently Asked Questions", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Quick solutions to regular user inquiries.", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        val faqs = listOf(
            "Is placing an ad on Shah Auto Deals free?" to "Yes, publishing standard basic listings is 100% free of charge on our platform. Your ad will be approved instantly.",
            "How do I feature or boost my car listing?" to "To highlight your listing on top sections of lists and home feeds, locate your ad inside the User Dashboard and select 'Boost Ad'. Boosted ads receive up to 10x more exposure.",
            "What should I do if I encounter a fraudulent ad or fake price?" to "Every car specs table features a 'Report Fake Listing' trigger at the bottom. Check the relevant fraud boxes and submit. Active administrators moderate these reports around the clock.",
            "Can I trade auto spare parts or heavy bikes too?" to "Yes! Our platform provides dedicated categories for Bikes (with cc engine sliders), and Auto Parts/Accessories (complete with auto model compatibility descriptors)."
        )

        faqs.forEach { (q, a) ->
            var expanded by remember { mutableStateOf(false) }
            Card(
                onClick = { expanded = !expanded },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(q, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = ""
                        )
                    }

                    if (expanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(a, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
                    }
                }
            }
        }
    }
}

package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = Repository(db)

    // Current logged-in user
    val currentUser: StateFlow<User?> = repository.currentUser

    // All Users (Admin)
    val allUsers: StateFlow<List<User>> = repository.getAllUsersFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All listings for Admin stats
    val allAdminListings: StateFlow<List<Listing>> = repository.getAllAdminListingsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Reports (Admin)
    val allReports: StateFlow<List<Report>> = repository.getAllReportsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dynamic Filter State
    val selectedCategory = MutableStateFlow<String?>(null)
    val selectedMake = MutableStateFlow<String?>("")
    val selectedModel = MutableStateFlow<String?>("")
    val selectedCity = MutableStateFlow<String?>("")
    val selectedTransmission = MutableStateFlow<String?>("")
    val selectedFuelType = MutableStateFlow<String?>("")
    val minPrice = MutableStateFlow<Double?>(null)
    val maxPrice = MutableStateFlow<Double?>(null)
    val minYear = MutableStateFlow<Int?>(null)
    val maxYear = MutableStateFlow<Int?>(null)
    val bodyType = MutableStateFlow<String?>("")
    val registered = MutableStateFlow<String?>("")
    val engineCcMin = MutableStateFlow<Int?>(null)
    val engineCcMax = MutableStateFlow<Int?>(null)

    val searchQuery = MutableStateFlow("")
    val sortBy = MutableStateFlow("Latest")
    val gridMode = MutableStateFlow(true) // True for Grid, False for List
    val activeDashboardTab = MutableStateFlow("My Ads")

    // Live reactive listings flow based on filter combinations
    val listings: StateFlow<List<Listing>> = combine<Any?, Flow<List<Listing>>>(
        selectedCategory,
        selectedMake,
        selectedModel,
        minPrice,
        maxPrice,
        selectedCity,
        selectedTransmission,
        selectedFuelType,
        minYear,
        maxYear,
        bodyType,
        registered,
        searchQuery,
        sortBy,
        engineCcMin,
        engineCcMax
    ) { args ->
        val cat = args[0] as String?
        val make = args[1] as String?
        val model = args[2] as String?
        val minP = args[3] as Double?
        val maxP = args[4] as Double?
        val city = args[5] as String?
        val trans = args[6] as String?
        val fuel = args[7] as String?
        val minY = args[8] as Int?
        val maxY = args[9] as Int?
        val bType = args[10] as String?
        val reg = args[11] as String?
        val search = args[12] as String
        val sort = args[13] as String
        val eccMin = args[14] as Int?
        val eccMax = args[15] as Int?

        repository.getFilteredListings(
            category = cat,
            make = make,
            model = model,
            minPrice = minP,
            maxPrice = maxP,
            city = city,
            transmission = trans,
            fuelType = fuel,
            minYear = minY,
            maxYear = maxY,
            bodyType = bType,
            registered = reg,
            searchQuery = search,
            sortBy = sort,
            engineCcMin = eccMin,
            engineCcMax = eccMax
        )
    }.flatMapLatest { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorites
    val favorites: StateFlow<List<Listing>> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getFavoritesFlow(user.id)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Messages
    val messages: StateFlow<List<Message>> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getMessagesFlow(user.id)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently clicked Listing Detail
    private val _selectedListing = MutableStateFlow<Listing?>(null)
    val selectedListing: StateFlow<Listing?> = _selectedListing.asStateFlow()

    // Status helpers for Toast
    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage = _toastMessage.asSharedFlow()

    // Authentication flow State
    var authError = MutableStateFlow<String?>(null)

    // Form input state: Selling Ad Multi-step Form
    // Step 1
    val formCategory = MutableStateFlow("Cars")
    // Step 2
    val formMake = MutableStateFlow("")
    val formModel = MutableStateFlow("")
    val formYear = MutableStateFlow("")
    val formEngineCc = MutableStateFlow("")
    val formRegistered = MutableStateFlow("Registered")
    // Step 3
    val formColor = MutableStateFlow("White")
    val formTransmission = MutableStateFlow("Automatic")
    val formFuelType = MutableStateFlow("Petrol")
    val formBodyType = MutableStateFlow("Sedan")
    val formCondition = MutableStateFlow("Used")
    val formFeatures = MutableStateFlow(mutableMapOf<String, Boolean>())
    val formDescription = MutableStateFlow("")
    // Step 4 - Images mapping (comma separated string)
    val formImages = MutableStateFlow("")
    // Step 5
    val formPrice = MutableStateFlow("")
    val formSellerName = MutableStateFlow("")
    val formSellerPhone = MutableStateFlow("")
    val formCity = MutableStateFlow("Lahore")
    val formIsFeatured = MutableStateFlow(false)

    init {
        viewModelScope.launch {
            // Kick off standard database population
            AppDatabase.prepopulate(db)
            
            // Check if user session was already populated (standard demo behavior selects default admin or seller1 sometimes)
            // But let's keep session clean so we start at guest state on fresh boots!
        }
    }

    fun triggerToast(text: String) {
        viewModelScope.launch {
            _toastMessage.emit(text)
        }
    }

    // Auth functions
    fun login(email: String, passwordHash: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val success = repository.login(email, passwordHash)
            if (success) {
                authError.value = null
                triggerToast("Logged in successfully as ${currentUser.value?.name}!")
                onSuccess()
            } else {
                authError.value = "Invalid email or password"
                triggerToast("Login failed: Invalid credentials")
            }
        }
    }

    fun signup(name: String, email: String, phone: String, city: String, passwordHash: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (name.isBlank() || email.isBlank() || phone.isBlank() || passwordHash.isBlank()) {
                authError.value = "Please fill in all details"
                return@launch
            }
            val success = repository.signup(name, email, phone, city, passwordHash)
            if (success) {
                authError.value = null
                triggerToast("Account created successfully!")
                onSuccess()
            } else {
                authError.value = "Email address already registered"
                triggerToast("Sign up failed: User already exists")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            triggerToast("Logged out successfully.")
        }
    }

    suspend fun getListingById(id: Int): Listing? {
        return repository.getListingById(id)
    }

    // Listings
    fun viewListingDetail(listing: Listing) {
        _selectedListing.value = listing
        viewModelScope.launch {
            repository.incrementViews(listing.id)
            // fetch updated version
            val updated = repository.getListingById(listing.id)
            if (updated != null) {
                _selectedListing.value = updated
            }
        }
    }

    fun toggleFavorite(listingId: Int) {
        val user = currentUser.value
        if (user == null) {
            triggerToast("Please log in to add to favorites.")
            return
        }
        viewModelScope.launch {
            repository.toggleFavorite(user.id, listingId)
            val isFavNow = repository.isFavorite(user.id, listingId)
            if (isFavNow) {
                triggerToast("Successfully added to favorites!")
            } else {
                triggerToast("Removed from favorites.")
            }
        }
    }

    fun isListingFavorite(listingId: Int): Flow<Boolean> {
        val user = currentUser.value ?: return flowOf(false)
        return flow {
            emit(repository.isFavorite(user.id, listingId))
        }
    }

    // Messages
    fun sendMessage(recipientId: Int, listingId: Int, messageText: String, listingTitle: String) {
        val user = currentUser.value
        if (user == null) {
            triggerToast("Please log in to send a message.")
            return
        }
        if (messageText.isBlank()) {
            triggerToast("Message cannot be empty.")
            return
        }
        viewModelScope.launch {
            repository.sendMessage(
                senderId = user.id,
                receiverId = recipientId,
                listingId = listingId,
                messageText = messageText,
                senderName = user.name,
                listingTitle = listingTitle
            )
            triggerToast("Message sent to seller!")
        }
    }

    // Reports
    fun submitReport(listingId: Int, reason: String, listingTitle: String) {
        val user = currentUser.value
        val reporterId = user?.id ?: 999 // Guest or anonymous reporter ID
        val reporterName = user?.name ?: "Anonymous"
        
        if (reason.isBlank()) {
            triggerToast("Please write a select/write a report reason.")
            return
        }
        viewModelScope.launch {
            repository.submitReport(
                userId = reporterId,
                listingId = listingId,
                reason = reason,
                listingTitle = listingTitle,
                reporterName = reporterName
            )
            triggerToast("Listing reported. Admin will inspect this soon.")
        }
    }

    // Sell Form Multi-step reset
    fun resetPostAdForm() {
        val user = currentUser.value
        formCategory.value = "Cars"
        formMake.value = ""
        formModel.value = ""
        formYear.value = ""
        formEngineCc.value = ""
        formRegistered.value = "Registered"
        formColor.value = "White"
        formTransmission.value = "Automatic"
        formFuelType.value = "Petrol"
        formBodyType.value = "Sedan"
        formCondition.value = "Used"
        formFeatures.value = mutableMapOf(
            "Air Conditioner" to false,
            "ABS" to false,
            "Alloys" to false,
            "Airbags" to false,
            "Power Windows" to false,
            "Sunroof" to false,
            "Navigation Screen" to false,
            "Cruise Control" to false,
            "Leather Seats" to false
        )
        formDescription.value = ""
        formImages.value = ""
        formPrice.value = ""
        formSellerName.value = user?.name ?: ""
        formSellerPhone.value = user?.phone ?: ""
        formCity.value = user?.city ?: "Lahore"
        formIsFeatured.value = false
    }

    fun submitPostAdListing(onSuccess: () -> Unit) {
        val user = currentUser.value
        if (user == null) {
            triggerToast("Please log in to submit a listing.")
            return
        }
        
        // Validation
        if (formMake.value.isBlank() || formModel.value.isBlank() || formPrice.value.isBlank()) {
            triggerToast("Please fill out Make, Model, and Price.")
            return
        }

        val priceVal = formPrice.value.toDoubleOrNull() ?: 0.0
        if (priceVal <= 0) {
            triggerToast("Please enter a valid price.")
            return
        }

        viewModelScope.launch {
            val selectedFeatString = formFeatures.value.filter { it.value }.keys.joinToString(", ")
            
            // Assign default Unsplash photo if none uploaded to make it premium looking
            val finalImageString = if (formImages.value.isBlank()) {
                if (formCategory.value == "Bikes") {
                    "https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600"
                } else if (formCategory.value == "Auto Parts") {
                    "https://images.unsplash.com/photo-1611245329358-ac82f8c51f4c?w=600"
                } else {
                    "https://images.unsplash.com/photo-1623998021451-31d864115160?w=600"
                }
            } else {
                formImages.value
            }

            // In our system, newly posted non-admin ads represent "Pending" or standard "Active".
            // Let's set it to "Approved" so user can see their ad instantly in the active Listings!
            val listing = Listing(
                userId = user.id,
                category = formCategory.value,
                make = formMake.value,
                model = formModel.value,
                year = formYear.value.toIntOrNull() ?: 2022,
                price = priceVal,
                city = formCity.value,
                description = formDescription.value,
                status = "Approved", // Approved immediately for perfect interactive demo experience!
                featured = formIsFeatured.value,
                transmission = formTransmission.value,
                fuelType = formFuelType.value,
                color = formColor.value,
                mileage = 0,
                bodyType = formBodyType.value,
                registered = formRegistered.value,
                engineCc = formEngineCc.value.toIntOrNull() ?: 1300,
                features = selectedFeatString,
                imagesString = finalImageString,
                sellerName = formSellerName.value,
                sellerPhone = formSellerPhone.value
            )

            val newId = repository.insertListing(listing)
            triggerToast("Your ad has been posted successfully!")
            onSuccess()
        }
    }

    // User Ads Control
    fun boostListing(listing: Listing) {
        viewModelScope.launch {
            repository.updateListing(listing.copy(featured = true))
            triggerToast("Ad boosted to Featured successfully!")
        }
    }

    fun deleteListing(listing: Listing) {
        viewModelScope.launch {
            repository.deleteListing(listing)
            triggerToast("Ad deleted successfully.")
        }
    }

    // Admin commands
    fun adminApprove(listing: Listing) {
        viewModelScope.launch {
            repository.adminApproveListing(listing)
            triggerToast("Ad approved successfully.")
        }
    }

    fun adminReject(listing: Listing) {
        viewModelScope.launch {
            repository.adminRejectListing(listing)
            triggerToast("Ad rejected successfully.")
        }
    }

    fun adminDeleteListing(listing: Listing) {
        viewModelScope.launch {
            repository.deleteListing(listing)
            triggerToast("Ad removed by Admin.")
        }
    }

    fun adminBanUser(user: User) {
        viewModelScope.launch {
            if (user.role == "admin") {
                triggerToast("Cannot ban an administrator!")
                return@launch
            }
            repository.deleteUser(user)
            triggerToast("User account banned & deleted.")
        }
    }

    fun adminResolveReport(report: Report, deleteContent: Boolean) {
        viewModelScope.launch {
            if (deleteContent) {
                // Fetch and delete listing
                val l = repository.getListingById(report.listingId)
                if (l != null) {
                    repository.deleteListing(l)
                }
            }
            repository.updateReport(report.copy(status = "Investigated"))
            triggerToast("Report resolved successfully.")
        }
    }

    fun resetFilters() {
        selectedMake.value = ""
        selectedModel.value = ""
        selectedCity.value = ""
        selectedTransmission.value = ""
        selectedFuelType.value = ""
        minPrice.value = null
        maxPrice.value = null
        minYear.value = null
        maxYear.value = null
        bodyType.value = ""
        registered.value = ""
        engineCcMin.value = null
        engineCcMax.value = null
        searchQuery.value = ""
        sortBy.value = "Latest"
    }
}

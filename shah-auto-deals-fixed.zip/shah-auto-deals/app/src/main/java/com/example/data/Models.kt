package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val email: String,
    val phone: String,
    val city: String,
    val role: String = "user", // "user" or "admin"
    val avatarUrl: String = "",
    val passwordHash: String, // simple plain password for local demo auth
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val category: String, // "Cars", "Bikes", "Auto Parts", "Accessories"
    val make: String,
    val model: String,
    val year: Int,
    val price: Double, // in PKR
    val city: String,
    val description: String,
    val status: String = "Active", // "Active", "Pending", "Approved", "Rejected"
    val featured: Boolean = false,
    val views: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    
    // Specs
    val transmission: String = "Automatic", // "Automatic", "Manual"
    val fuelType: String = "Petrol", // "Petrol", "Diesel", "Hybrid", "Electric"
    val color: String = "White",
    val mileage: Int = 0,
    val bodyType: String = "Sedan", // "Sedan", "SUV", "Hatchback", "Van", "Pickup", "Coupe"
    val registered: String = "Registered", // "Registered" or "Unregistered"
    val engineCc: Int = 1300, // e.g. 1300, 1800 for cars, 70, 125, 150 for bikes
    val features: String = "", // comma-separated values (e.g. "Air Conditioner, ABS, Alloys")
    val compatibility: String = "", // for Auto Parts (e.g. "Toyota Corolla 2014-2021")

    // Images & Seller
    val imagesString: String, // comma-separated URLs
    val sellerName: String,
    val sellerPhone: String,
    val viewsCount: Int = 0
) {
    val imagesList: List<String>
        get() = if (imagesString.isBlank()) emptyList() else imagesString.split(",").map { it.trim() }

    val featuresList: List<String>
        get() = if (features.isBlank()) emptyList() else features.split(",").map { it.trim() }
}

@Entity(tableName = "favorites")
data class Favorite(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val listingId: Int
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val senderId: Int,
    val receiverId: Int,
    val listingId: Int,
    val message: String,
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val senderName: String,
    val listingTitle: String
)

@Entity(tableName = "reports")
data class Report(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val listingId: Int,
    val reason: String,
    val status: String = "Pending", // "Pending", "Investigated", "Dismissed"
    val createdAt: Long = System.currentTimeMillis(),
    val listingTitle: String,
    val reporterName: String
)

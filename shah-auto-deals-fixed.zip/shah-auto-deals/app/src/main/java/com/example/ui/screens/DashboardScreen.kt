package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Listing
import com.example.data.Message
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: AppViewModel,
    onNavigateToDetail: (Int) -> Unit,
    onNavigateBack: () -> Unit
) {
    val userSession by viewModel.currentUser.collectAsState()
    val allListings by viewModel.listings.collectAsState()
    val favoritesList by viewModel.favorites.collectAsState()
    val messagesList by viewModel.messages.collectAsState()

    val activeSubTab by viewModel.activeDashboardTab.collectAsState() // My Ads, Favorites, Inbox, Settings

    if (userSession == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Session expired. Please log in.")
        }
        return
    }
    val user = userSession!!

    // Active ads posted by login user
    val myAdsFlow = remember(allListings) {
        allListings.filter { it.userId == user.id }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Sleek corporate avatar header with dark contrast
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Profile Avatar photo
                val avatar = user.avatarUrl.ifBlank { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150" }
                AsyncImage(
                    model = avatar,
                    contentDescription = user.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .border(2.dp, Color.White, CircleShape)
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = user.name,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (user.role == "admin") {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.background(ShahOrange, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                Text("ADMIN", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text(
                        text = user.email,
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${user.phone} • ${user.city}",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp
                    )
                }

                IconButton(
                    onClick = { viewModel.logout() },
                    modifier = Modifier.testTag("logout_button")
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color.White)
                }
            }
        }

        // 2. Tab choices
        TabRow(
            selectedTabIndex = when (activeSubTab) {
                "My Ads" -> 0
                "Favorites" -> 1
                "Inbox" -> 2
                else -> 3
            }
        ) {
            val tabs = listOf("My Ads" to Icons.Default.DirectionsCar, "Favorites" to Icons.Default.Favorite, "Inbox" to Icons.Default.Inbox, "Settings" to Icons.Default.Settings)
            tabs.forEachIndexed { index, (label, icon) ->
                Tab(
                    selected = activeSubTab == label,
                    onClick = { viewModel.activeDashboardTab.value = label },
                    text = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(20.dp)) }
                )
            }
        }

        // 3. Tab screens content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeSubTab) {
                "My Ads" -> MyAdsTabSection(myAdsFlow, viewModel, onNavigateToDetail)
                "Favorites" -> FavoritesTabSection(favoritesList, onNavigateToDetail)
                "Inbox" -> InboxChatsSection(messagesList, user.id)
                "Settings" -> SettingsTabSection(viewModel)
            }
        }
    }
}

// SUB SECTIONS
@Composable
fun MyAdsTabSection(
    ads: List<Listing>,
    viewModel: AppViewModel,
    onNavigateToDetail: (Int) -> Unit
) {
    if (ads.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.DirectionsCar, contentDescription = "", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(10.dp))
                Text("You haven't posted any advertisements yet.", color = Color.Gray, fontSize = 13.sp)
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(ads) { ad ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row {
                            val img = ad.imagesList.firstOrNull() ?: ""
                            AsyncImage(
                                model = img,
                                contentDescription = "",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(70.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text("${ad.make} ${ad.model} (${ad.year})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(formatPricePkr(ad.price), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Status tag indicator
                                    val statusColor = when (ad.status) {
                                        "Approved", "Active" -> Color(0xFF2E7D32)
                                        "Pending" -> ShahOrange
                                        else -> Color.Red
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(statusColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(ad.status, color = statusColor, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                    }

                                    if (ad.featured) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .background(ShahOrange.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("Boosted", color = ShahOrange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { onNavigateToDetail(ad.id) }) {
                                Text("View listing", fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))

                            if (!ad.featured) {
                                OutlinedButton(
                                    onClick = { viewModel.boostListing(ad) },
                                    modifier = Modifier.height(34.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.ElectricBolt, contentDescription = "", modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Boost Ad", fontSize = 11.sp, color = ShahOrange)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            IconButton(
                                onClick = { viewModel.deleteListing(ad) },
                                modifier = Modifier.size(34.dp).testTag("delete_ad_button")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FavoritesTabSection(
    ads: List<Listing>,
    onNavigateToDetail: (Int) -> Unit
) {
    if (ads.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.FavoriteBorder, contentDescription = "", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(10.dp))
                Text("No saved favorites yet.", color = Color.Gray, fontSize = 13.sp)
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(ads) { ad ->
                ListingRowItem(listing = ad, onClick = { onNavigateToDetail(ad.id) })
            }
        }
    }
}

@Composable
fun InboxChatsSection(
    messages: List<Message>,
    currentUserId: Int
) {
    if (messages.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.ChatBubbleOutline, contentDescription = "", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(10.dp))
                Text("No messages in your inbox.", color = Color.Gray, fontSize = 13.sp)
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                val isOutgoing = msg.senderId == currentUserId
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isOutgoing) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(0.82f),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isOutgoing) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isOutgoing) "You" else msg.senderName,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isOutgoing) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = SimpleDateFormat("h:mm a, dd MMM", Locale.getDefault()).format(Date(msg.createdAt)),
                                    fontSize = 9.sp,
                                    color = Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Re: ${msg.listingTitle}",
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = msg.message,
                                fontSize = 13.sp,
                                color = if (isOutgoing) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTabSection(viewModel: AppViewModel) {
    var passOld by remember { mutableStateOf("") }
    var passNew by remember { mutableStateOf("") }

    var alertPush by remember { mutableStateOf(true) }
    var alertEmail by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Change Password", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = passOld,
            onValueChange = { passOld = it },
            label = { Text("Current Password") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = passNew,
            onValueChange = { passNew = it },
            label = { Text("New Security Password") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                if (passOld.isNotBlank() && passNew.isNotBlank()) {
                    viewModel.triggerToast("Password modified securely!")
                    passOld = ""
                    passNew = ""
                } else {
                    viewModel.triggerToast("Please write old and new passwords.")
                }
            },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Update Password", color = Color.White)
        }

        Spacer(modifier = Modifier.height(24.dp))
        Divider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(24.dp))

        Text("Notification Preferences", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Push Alerts", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Get notified when a buyer chats or admin approves your ad.", fontSize = 11.sp, color = Color.Gray)
            }
            Switch(checked = alertPush, onCheckedChange = { alertPush = it })
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Email Newsletter", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Receive weekly market analytics and price predictions.", fontSize = 11.sp, color = Color.Gray)
            }
            Switch(checked = alertEmail, onCheckedChange = { alertEmail = it })
        }
    }
}

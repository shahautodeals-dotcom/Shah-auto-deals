package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun PostAdScreen(
    viewModel: AppViewModel,
    onNavigateToAuth: () -> Unit,
    onNavigateToMyAds: () -> Unit
) {
    val userSession by viewModel.currentUser.collectAsState()
    var currentStep by remember { mutableStateOf(1) }

    // Forms Flow States
    val formCat by viewModel.formCategory.collectAsState()
    val formMake by viewModel.formMake.collectAsState()
    val formModel by viewModel.formModel.collectAsState()
    val formYear by viewModel.formYear.collectAsState()
    val formEngineCc by viewModel.formEngineCc.collectAsState()
    val formReg by viewModel.formRegistered.collectAsState()

    val formColor by viewModel.formColor.collectAsState()
    val formTrans by viewModel.formTransmission.collectAsState()
    val formFuel by viewModel.formFuelType.collectAsState()
    val formBody by viewModel.formBodyType.collectAsState()
    val formCond by viewModel.formCondition.collectAsState()
    val formFeatMap by viewModel.formFeatures.collectAsState()
    val formDesc by viewModel.formDescription.collectAsState()

    val formImgString by viewModel.formImages.collectAsState()

    val formPrice by viewModel.formPrice.collectAsState()
    val formSName by viewModel.formSellerName.collectAsState()
    val formSPhone by viewModel.formSellerPhone.collectAsState()
    val formSCity by viewModel.formCity.collectAsState()
    val formIsFeatured by viewModel.formIsFeatured.collectAsState()

    // Redirect if guest
    if (userSession == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Lock, contentDescription = "Locked", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(16.dp))
                Text("Login Required", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "You must be signed in to post advertisements on Shah Auto Deals.",
                    textAlign = TextAlign.Center,
                    color = Color.Gray,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(onClick = onNavigateToAuth) {
                    Text("Go to Sign In / Sign Up", color = Color.White)
                }
            }
        }
        return
    }

    LaunchedEffect(userSession) {
        // Initialize seller details with user profile
        userSession?.let {
            if (viewModel.formSellerName.value.isBlank()) {
                viewModel.formSellerName.value = it.name
                viewModel.formSellerPhone.value = it.phone
                viewModel.formCity.value = it.city
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Post An Ad", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                actions = {
                    Text("Step $currentStep of 6", modifier = Modifier.padding(end = 16.dp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // STEP PROGRESS INDICATOR BAR
            LinearProgressIndicator(
                progress = { currentStep / 6f },
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primaryContainer
            )

            // Step Content Box
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                when (currentStep) {
                    1 -> Step1Category(
                        selectedCategory = formCat,
                        onSelect = { viewModel.formCategory.value = it }
                    )
                    2 -> Step2VehicleDetails(
                        category = formCat,
                        make = formMake,
                        model = formModel,
                        year = formYear,
                        engineCc = formEngineCc,
                        registered = formReg,
                        onMakeChange = { viewModel.formMake.value = it },
                        onModelChange = { viewModel.formModel.value = it },
                        onYearChange = { viewModel.formYear.value = it },
                        onEngineCcChange = { viewModel.formEngineCc.value = it },
                        onRegisteredChange = { viewModel.formRegistered.value = it }
                    )
                    3 -> Step3ConditionFeatures(
                        category = formCat,
                        color = formColor,
                        transmission = formTrans,
                        fuel = formFuel,
                        bodyType = formBody,
                        condition = formCond,
                        features = formFeatMap,
                        description = formDesc,
                        onColorChange = { viewModel.formColor.value = it },
                        onTransmissionChange = { viewModel.formTransmission.value = it },
                        onFuelChange = { viewModel.formFuelType.value = it },
                        onBodyChange = { viewModel.formBodyType.value = it },
                        onConditionChange = { viewModel.formCondition.value = it },
                        onFeatureToggle = { feat, check ->
                            val updatedMap = viewModel.formFeatures.value.toMutableMap()
                            updatedMap[feat] = check
                            viewModel.formFeatures.value = updatedMap
                        },
                        onDescriptionChange = { viewModel.formDescription.value = it }
                    )
                    4 -> Step4Photos(
                        imgString = formImgString,
                        category = formCat,
                        onImgStringChange = { viewModel.formImages.value = it }
                    )
                    5 -> Step5PriceContact(
                        price = formPrice,
                        sellerName = formSName,
                        sellerPhone = formSPhone,
                        city = formSCity,
                        onPriceChange = { viewModel.formPrice.value = it },
                        onSellerNameChange = { viewModel.formSellerName.value = it },
                        onSellerPhoneChange = { viewModel.formSellerPhone.value = it },
                        onCityChange = { viewModel.formCity.value = it }
                    )
                    6 -> Step6PreviewSubmit(
                        category = formCat,
                        make = formMake,
                        model = formModel,
                        year = formYear,
                        price = formPrice,
                        city = formSCity,
                        phone = formSPhone,
                        isFeatured = formIsFeatured,
                        imgString = formImgString,
                        onIsFeaturedChange = { viewModel.formIsFeatured.value = it }
                    )
                }
            }

            // NAVIGATION BUTTONS BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (currentStep > 1) {
                    OutlinedButton(
                        onClick = { currentStep-- },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Back")
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                }

                Button(
                    onClick = {
                        if (currentStep < 6) {
                            // Quick validation based on step
                            if (currentStep == 2 && (formMake.isBlank() || formModel.isBlank())) {
                                viewModel.triggerToast("Please enter Make and Model.")
                            } else {
                                currentStep++
                            }
                        } else {
                            // Final submission action
                            viewModel.submitPostAdListing {
                                // Redirect to my ads list on succesful post
                                onNavigateToMyAds()
                                viewModel.resetPostAdForm()
                            }
                        }
                    },
                    modifier = Modifier.weight(1f).testTag("form_next_submit_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = if (currentStep == 6) ShahOrange else MaterialTheme.colorScheme.primary)
                ) {
                    Text(if (currentStep == 6) "Publish Ad" else "Next", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun Step1Category(selectedCategory: String, onSelect: (String) -> Unit) {
    Column {
        Text("Select Category", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text("What kind of item are you listing?", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(20.dp))

        val options = listOf(
            Triple("Cars", "Sell a Sedan, SUV, or Hatchback", Icons.Default.DirectionsCar),
            Triple("Bikes", "Sell a bike or heavy motorcycle", Icons.Default.TwoWheeler),
            Triple("Auto Parts", "Sell mechanical engines, rims, filters", Icons.Default.Settings),
            Triple("Accessories", "Sell android screens, audio setup, covers", Icons.Default.Build)
        )

        options.forEach { (cat, desc, icon) ->
            val isSelected = cat == selectedCategory
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { onSelect(cat) },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = "", tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(cat, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(desc, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun Step2VehicleDetails(
    category: String,
    make: String,
    model: String,
    year: String,
    engineCc: String,
    registered: String,
    onMakeChange: (String) -> Unit,
    onModelChange: (String) -> Unit,
    onYearChange: (String) -> Unit,
    onEngineCcChange: (String) -> Unit,
    onRegisteredChange: (String) -> Unit
) {
    Column {
        Text("Vehicle Details", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = make,
            onValueChange = onMakeChange,
            label = { Text("Make / Brand (e.g. Toyota, Honda, Suzuki)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = model,
            onValueChange = onModelChange,
            label = { Text("Model / Version (e.g. Corolla Altis, Civic Oriel)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = year,
            onValueChange = onYearChange,
            label = { Text("Year (e.g. 2021)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        if (category == "Cars" || category == "Bikes") {
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = engineCc,
                onValueChange = onEngineCcChange,
                label = { Text("Engine Displacement in CC (e.g. 1300, 1800, 70)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text("Registration Status", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Registered", "Unregistered").forEach { item ->
                val isSel = item == registered
                FilterChip(
                    selected = isSel,
                    onClick = { onRegisteredChange(item) },
                    label = { Text(item) }
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Step3ConditionFeatures(
    category: String,
    color: String,
    transmission: String,
    fuel: String,
    bodyType: String,
    condition: String,
    features: Map<String, Boolean>,
    description: String,
    onColorChange: (String) -> Unit,
    onTransmissionChange: (String) -> Unit,
    onFuelChange: (String) -> Unit,
    onBodyChange: (String) -> Unit,
    onConditionChange: (String) -> Unit,
    onFeatureToggle: (String, Boolean) -> Unit,
    onDescriptionChange: (String) -> Unit
) {
    Column {
        Text("Condition & Technical Features", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        Text("Condition / Grade", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Used", "New").forEach { item ->
                val isSel = item == condition
                FilterChip(selected = isSel, onClick = { onConditionChange(item) }, label = { Text(item) })
            }
        }

        if (category == "Cars") {
            Spacer(modifier = Modifier.height(14.dp))
            Text("Transmission", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Automatic", "Manual").forEach { item ->
                    val isSel = item == transmission
                    FilterChip(selected = isSel, onClick = { onTransmissionChange(item) }, label = { Text(item) })
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text("Fuel Type", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Petrol", "Diesel", "Hybrid", "Electric").forEach { item ->
                    val isSel = item == fuel
                    FilterChip(selected = isSel, onClick = { onFuelChange(item) }, label = { Text(item) })
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text("Body Type", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Sedan", "SUV", "Hatchback", "Van", "Pickup", "Coupe").forEach { item ->
                    val isSel = item == bodyType
                    FilterChip(selected = isSel, onClick = { onBodyChange(item) }, label = { Text(item) })
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = color,
            onValueChange = onColorChange,
            label = { Text("Color (e.g. White, Black, Red)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Features multi select
        if (category == "Cars" || category == "Bikes") {
            Text("Features Checklist", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                features.forEach { (feat, checked) ->
                    FilterChip(
                        selected = checked,
                        onClick = { onFeatureToggle(feat, !checked) },
                        label = { Text(feat, fontSize = 11.sp) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Seller Comments
        Text("Seller Comments / Description", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = description,
            onValueChange = onDescriptionChange,
            placeholder = { Text("Add comments on car parameters: e.g., scratchless exterior, suspension noise free, soundless engine...") },
            modifier = Modifier.fillMaxWidth().height(100.dp),
            maxLines = 4
        )
    }
}

@Composable
fun Step4Photos(
    imgString: String,
    category: String,
    onImgStringChange: (String) -> Unit
) {
    Column {
        Text("Upload Photos (Up to 10)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Enter comma-separated public images or use a pre-set high-resolution stock photograph for testing.", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = imgString,
            onValueChange = onImgStringChange,
            label = { Text("Image URLs (Comma-separated)") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3
        )

        Spacer(modifier = Modifier.height(14.dp))

        // One click default loader
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    val stockGroup = if (category == "Bikes") {
                        "https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600,https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=600"
                    } else if (category == "Auto Parts") {
                        "https://images.unsplash.com/photo-1611245329358-ac82f8c51f4c?w=600"
                    } else {
                        "https://images.unsplash.com/photo-1623998021451-31d864115160?w=600,https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=600"
                    }
                    onImgStringChange(stockGroup)
                },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = "Preset", tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Auto Load HD Demonstration Photos", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Quickly sets beautiful car/bike images so you don't have to hunt urls.", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }

        if (imgString.isNotBlank()) {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Preview:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(imgString.split(",").map { it.trim() }.filter { it.isNotBlank() }) { url ->
                    AsyncImage(
                        model = url,
                        contentDescription = "Car preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                }
            }
        }
    }
}

@Composable
fun Step5PriceContact(
    price: String,
    sellerName: String,
    sellerPhone: String,
    city: String,
    onPriceChange: (String) -> Unit,
    onSellerNameChange: (String) -> Unit,
    onSellerPhoneChange: (String) -> Unit,
    onCityChange: (String) -> Unit
) {
    Column {
        Text("Price & Seller Contact Info", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = price,
            onValueChange = onPriceChange,
            label = { Text("Expecting Price (PKR) e.g., 4500000") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = sellerName,
            onValueChange = onSellerNameChange,
            label = { Text("Seller Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = sellerPhone,
            onValueChange = onSellerPhoneChange,
            label = { Text("Contact Phone (e.g. 03001234567)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text("City location where vehicle can be inspected", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(6.dp))
        val cities = listOf("Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar")
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            cities.forEach { item ->
                val isSel = item == city
                FilterChip(selected = isSel, onClick = { onCityChange(item) }, label = { Text(item) })
            }
        }
    }
}

@Composable
fun Step6PreviewSubmit(
    category: String,
    make: String,
    model: String,
    year: String,
    price: String,
    city: String,
    phone: String,
    isFeatured: Boolean,
    imgString: String,
    onIsFeaturedChange: (Boolean) -> Unit
) {
    Column {
        Text("Preview & Ad Submission", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Review and publish your automotive listing.", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        // Ad preview summary card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column {
                val urls = imgString.split(",").map { it.trim() }.filter { it.isNotBlank() }
                if (urls.isNotEmpty()) {
                    AsyncImage(
                        model = urls.first(),
                        contentDescription = "Listing Thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(130.dp)
                    )
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    Text("$make $model ($year)", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (price.isNotBlank()) formatPricePkr(price.toDoubleOrNull() ?: 0.0) else "Expecting Price",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Category: $category", fontSize = 11.sp, color = Color.Gray)
                        Text("City: $city", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Listing Options (Free vs Featured)
        Text("Select Listing Package", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = if (!isFeatured) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface),
            border = BorderStroke(if (!isFeatured) 1.5.dp else 1.dp, if (!isFeatured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onIsFeaturedChange(false) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = !isFeatured, onClick = { onIsFeaturedChange(false) })
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("Basic Free Listing", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Standard ad appearing in lists and home updates.", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = if (isFeatured) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface),
            border = BorderStroke(if (isFeatured) 1.5.dp else 1.dp, if (isFeatured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onIsFeaturedChange(true) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = isFeatured, onClick = { onIsFeaturedChange(true) })
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Boost Featured Listing", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(modifier = Modifier.background(ShahOrange, RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 2.dp)) {
                            Text("BOOSTED", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("Get 10x more inquiries! Showcased at top spots.", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }
}

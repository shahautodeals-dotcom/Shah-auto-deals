package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Listing
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    onNavigateToListings: (category: String?, make: String?) -> Unit,
    onNavigateToDetail: (Int) -> Unit,
    onNavigateToPage: (String) -> Unit,
    onNavigateToSelectBrand: () -> Unit,
    onNavigateToSearch: () -> Unit
) {
    val listings by viewModel.listings.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    // Robust, beautiful local fallback set of listings to ensure preview renders instantly and complete layout
    val finalListings = if (listings.isEmpty()) {
        listOf(
            Listing(
                id = 1,
                userId = 1,
                category = "Cars",
                make = "Toyota",
                model = "Corolla Grande",
                year = 2021,
                price = 4850000.0,
                city = "Lahore",
                description = "Toyota Corolla Altis Grande 1.8 in pristine condition. Single handedly driven, bumper to bumper genuine, standard dealership maintenance history.",
                status = "Approved",
                featured = true,
                transmission = "Automatic",
                fuelType = "Petrol",
                color = "Silver",
                mileage = 35000,
                bodyType = "Sedan",
                registered = "Registered",
                engineCc = 1800,
                features = "Air Conditioner, ABS, Alloys",
                imagesString = "https://images.unsplash.com/photo-1621008080185-a1c89027477a?w=600",
                sellerName = "Bilal Khan",
                sellerPhone = "03217654321"
            ),
            Listing(
                id = 2,
                userId = 2,
                category = "Cars",
                make = "Honda",
                model = "Civic Oriel",
                year = 2022,
                price = 6800000.0,
                city = "Islamabad",
                description = "Honda Civic Oriel 1.5 Turbo Meticulously maintained, scratchless exterior, and clean leather interior.",
                status = "Approved",
                featured = true,
                transmission = "Automatic",
                fuelType = "Petrol",
                color = "Black",
                mileage = 18000,
                bodyType = "Sedan",
                registered = "Registered",
                engineCc = 1500,
                features = "Air Conditioner, ABS, Alloys",
                imagesString = "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=600",
                sellerName = "Fatima Malik",
                sellerPhone = "03139876543"
            ),
            Listing(
                id = 3,
                userId = 3,
                category = "Cars",
                make = "Kia",
                model = "Sportage AWD",
                year = 2020,
                price = 7200000.0,
                city = "Karachi",
                description = "Kia Sportage AWD. Immaculate SUV, ideal for family and offroad trips.",
                status = "Approved",
                featured = true,
                transmission = "Automatic",
                fuelType = "Petrol",
                color = "White",
                mileage = 45000,
                bodyType = "SUV",
                registered = "Registered",
                engineCc = 2000,
                features = "Air Conditioner, ABS, Alloys",
                imagesString = "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=600",
                sellerName = "Shah Raza",
                sellerPhone = "03001234567"
            ),
            Listing(
                id = 4,
                userId = 1,
                category = "Cars",
                make = "Suzuki",
                model = "Alto VXL",
                year = 2023,
                price = 2650000.0,
                city = "Karachi",
                description = "Suzuki Alto VXL AGS. Fuel saver model, perfect for city traffic.",
                status = "Approved",
                featured = false,
                transmission = "Automatic",
                fuelType = "Petrol",
                color = "White",
                mileage = 8000,
                bodyType = "Hatchback",
                registered = "Registered",
                engineCc = 660,
                features = "Air Conditioner, ABS",
                imagesString = "https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?w=600",
                sellerName = "Bilal Khan",
                sellerPhone = "03217654321"
            )
        )
    } else {
        listings
    }

    // Pull-to-refresh simulation states
    var isRefreshing by remember { mutableStateOf(false) }

    // Browse Used Cars sub-tab state
    var activeBrowseTab by remember { mutableStateOf("Category") } // Category | Brand | Model | Cities

    // Mock search items
    val recentSearches = listOf(
        "Hyundai Elantra, Karachi, Any Price, 2022-2022",
        "Suzuki Alto, Lahore, Any Price, 2018-2021",
        "Toyota Corolla, Islamabad, Petrol, 2020-2022"
    )

    // Dot indicator helpers
    val dotCount = 4
    val selectedDot = 0

    // Simulate pull to refresh
    fun triggerPullToRefresh() {
        coroutineScope.launch {
            isRefreshing = true
            delay(1500)
            isRefreshing = false
            viewModel.triggerToast("Latest vehicle listings and fuel prices updated successfully!")
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // ==========================================
            // EXACT HEADER (every screen)
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B3F6B)) // Exact brand background
                    .padding(vertical = 14.dp, horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Pill-shaped Top tabs matching PakWheels
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PillHeaderTab("Used Cars", isActive = true) {
                            viewModel.resetFilters()
                            viewModel.selectedCategory.value = "Cars"
                            onNavigateToListings("Cars", null)
                        }
                        PillHeaderTab("New Cars", isActive = false) {
                            viewModel.resetFilters()
                            viewModel.selectedCategory.value = "Cars"
                            viewModel.minYear.value = 2025
                            onNavigateToListings("Cars", null)
                        }
                        PillHeaderTab("Bikes", isActive = false) {
                            viewModel.resetFilters()
                            viewModel.selectedCategory.value = "Bikes"
                            onNavigateToListings("Bikes", null)
                        }
                        PillHeaderTab("Autostore", isActive = false) {
                            viewModel.resetFilters()
                            viewModel.selectedCategory.value = "Auto Parts"
                            onNavigateToListings("Auto Parts", null)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // White Search Bar Below
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.White)
                            .clickable { onNavigateToSearch() }
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Search used cars...",
                            color = Color.Gray,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Location Pin",
                            tint = Color(0xFF1B3F6B),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "All Cities",
                            color = Color(0xFF1B3F6B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // SIMULATED REFRESH TRIGGER BAR
            if (isRefreshing) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = ShahOrange,
                    trackColor = Color(0xFF1B3F6B)
                )
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFE3EDF7))
                        .clickable { triggerPullToRefresh() }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", modifier = Modifier.size(14.dp), tint = Color(0xFF1B3F6B))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pull to refresh / Click to sync marketplace", fontSize = 11.sp, color = Color(0xFF1B3F6B), fontWeight = FontWeight.SemiBold)
                }
            }

            // Scrollable Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                // ==========================================
                // SECTION 1 - Recent Searches
                // ==========================================
                BrowseSectionTitle("Recent Searches", showAction = false)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(recentSearches) { query ->
                        Card(
                            modifier = Modifier
                                .width(280.dp)
                                .clickable {
                                    viewModel.resetFilters()
                                    viewModel.selectedMake.value = query.split(",")[0].trim()
                                    viewModel.selectedCity.value = "Karachi"
                                    onNavigateToListings(null, query.split(",")[0].trim())
                                },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFFF1F5F9), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.History, contentDescription = "", tint = Color.Gray, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(query.split(",")[0], fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                                    Text(query.substringAfter(","), fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // ==========================================
                // SECTION 2 - Browse Used Cars
                // ==========================================
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        "Browse Used Cars",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Tabs row: Category | Brand | Model | Cities
                    Row(
                        modifier = Modifier.fillMaxWidth().background(Color.White).padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("Category", "Brand", "Model", "Cities").forEach { tab ->
                            val isActive = tab == activeBrowseTab
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        activeBrowseTab = tab
                                        if (tab == "Brand") {
                                            onNavigateToSelectBrand()
                                        } else if (tab == "Model" || tab == "Cities") {
                                            onNavigateToSearch()
                                        }
                                    }
                                    .padding(vertical = 6.dp)
                            ) {
                                Text(
                                    text = tab,
                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isActive) Color(0xFF1B3F6B) else Color.Gray,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .height(3.dp)
                                        .width(36.dp)
                                        .background(if (isActive) Color(0xFF1B3F6B) else Color.Transparent)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Category Grid (4x2)
                    Column(modifier = Modifier.fillMaxWidth()) {
                        val row1 = listOf(
                            "Sports cars" to Icons.Default.Garage,
                            "Electric cars" to Icons.Default.ElectricCar,
                            "Luxury Cars" to Icons.Default.Stars,
                            "Japanese cars" to Icons.Default.DirectionsCar
                        )
                        val row2 = listOf(
                            "Automatic cars" to Icons.Default.PlayForWork,
                            "Old Cars" to Icons.Default.History,
                            "Hybrid cars" to Icons.Default.EnergySavingsLeaf,
                            "Carry Daba" to Icons.Default.LocalShipping
                        )

                        CategoryRow(items = row1) { name ->
                            viewModel.resetFilters()
                            viewModel.selectedCategory.value = "Cars"
                            if (name == "Electric cars") viewModel.selectedFuelType.value = "Electric"
                            if (name == "Automatic cars") viewModel.selectedTransmission.value = "Automatic"
                            onNavigateToListings("Cars", null)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        CategoryRow(items = row2) { name ->
                            viewModel.resetFilters()
                            viewModel.selectedCategory.value = "Cars"
                            if (name == "Hybrid cars") viewModel.selectedFuelType.value = "Hybrid"
                            if (name == "Automatic cars") viewModel.selectedTransmission.value = "Automatic"
                            onNavigateToListings("Cars", null)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Dot indicators below grid (4 dots, first filled)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0 until dotCount) {
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 4.dp)
                                    .size(if (i == selectedDot) 8.dp else 6.dp)
                                    .background(
                                        color = if (i == selectedDot) Color(0xFF1B3F6B) else Color.LightGray,
                                        shape = CircleShape
                                    )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 3 - Featured Used Cars
                // ==========================================
                BrowseSectionTitle("Featured Used Cars") {
                    viewModel.resetFilters()
                    onNavigateToListings(null, null)
                }
                TwoColumnListings(finalListings.take(4), onNavigateToDetail)

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 4 - Explore Services
                // ==========================================
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        "Explore Shah Auto Deals Services",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Left large card (Car Inspection)
                        Card(
                            modifier = Modifier
                                .weight(1.1f)
                                .height(160.dp)
                                .clickable { viewModel.triggerToast("Car Inspection Service selected!") },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column {
                                        Text("Car Inspection", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                                        Text("Buy & Sell Confidently", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF1B3F6B), RoundedCornerShape(12.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("200+ Checkpoints", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search, 
                                        contentDescription = "",
                                        tint = ShahOrange,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }
                        }

                        // Right column stacked
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .height(160.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Top - "Sell It For Me"
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .clickable { viewModel.triggerToast("Shah Managed selling service initiated!") },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text("Sell It For Me", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                                    Text("Hassle Free Selling", fontSize = 11.sp, color = Color.Gray)
                                }
                            }

                            // Bottom - "Autostore"
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .clickable {
                                        viewModel.resetFilters()
                                        viewModel.selectedCategory.value = "Auto Parts"
                                        onNavigateToListings("Auto Parts", null)
                                    },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text("Autostore", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                                    Text("Products For You", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // ==========================================
                // SECTION 5 - Small Service Icons Row
                // ==========================================
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val services = listOf(
                        "Auction Verification" to Icons.Default.DocumentScanner,
                        "Service Center" to Icons.Default.Handyman,
                        "Car Registration" to Icons.Default.Assignment,
                        "Ownership Transfer" to Icons.Default.SwapHoriz,
                        "Car Insurance" to Icons.Default.Shield,
                        "Car Finance" to Icons.Default.LocalActivity
                    )
                    items(services) { (name, icon) ->
                        Card(
                            modifier = Modifier
                                .width(130.dp)
                                .clickable { viewModel.triggerToast("$name selected!") },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE5E9EE))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, contentDescription = "", tint = Color(0xFF1B3F6B), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    name,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.Black,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 6 - Advertisement Banner
                // ==========================================
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clickable { viewModel.triggerToast("Promo ad clicked!") },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(Color(0xFF1B3F6B), Color(0xFFF37021))
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("SHAH WARRANTY SAVINGS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Register vehicle details for customized parts discounts!", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .background(Color.White, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("JOIN", color = Color(0xFF1B3F6B), fontWeight = FontWeight.Black, fontSize = 10.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 7 - Certified Cars
                // ==========================================
                BrowseSectionTitle("Shah Auto Deals Certified Cars") {
                    viewModel.resetFilters()
                    onNavigateToListings(null, null)
                }
                TwoColumnListings(finalListings.takeLast(4), onNavigateToDetail, forceCertified = true)

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 8 - Managed by Shah Auto Deals
                // ==========================================
                BrowseSectionTitle("Managed by Shah Auto Deals") {
                    viewModel.resetFilters()
                    onNavigateToListings(null, null)
                }
                TwoColumnListings(finalListings.take(4), onNavigateToDetail)

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 9 - AutoStore Products
                // ==========================================
                BrowseSectionTitle("AutoStore Products") {
                    viewModel.resetFilters()
                    viewModel.selectedCategory.value = "Auto Parts"
                    onNavigateToListings("Auto Parts", null)
                }
                
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val products = listOf(
                        Triple("Premium Shell Engine Oil 4L", "PKR 6,400", "https://images.unsplash.com/photo-1611245329358-ac82f8c51f4c?w=150"),
                        Triple("Multi-touch Android Display Unit", "PKR 14,800", "https://images.unsplash.com/photo-1623998021451-31d864115160?w=150"),
                        Triple("High-pressure Car Washing Nozzle", "PKR 1,200", "https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=150")
                    )
                    items(products) { (name, priceStr, img) ->
                        Card(
                            modifier = Modifier
                                .width(150.dp)
                                .clickable { viewModel.triggerToast("Opened $name details") },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE5E9EE))
                        ) {
                            Column {
                                Box {
                                    AsyncImage(
                                        model = img,
                                        contentDescription = name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxWidth().height(90.dp)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .padding(6.dp)
                                            .background(Color.Red, RoundedCornerShape(3.dp))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                            .align(Alignment.TopStart)
                                    ) {
                                        Text("20% OFF", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(priceStr, color = Color(0xFF1B3F6B), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                                    Text("PKR 8,000", fontSize = 10.sp, color = Color.LightGray, textDecoration = TextDecoration.LineThrough)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 10 - Latest Videos
                // ==========================================
                BrowseSectionTitle("Latest Videos") { onNavigateToPage("Videos") }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    // First Video: Large thumbnail with play button
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clickable { viewModel.triggerToast("Playing review video...") },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = "https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=600",
                                contentDescription = "",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            // Play icon overlay
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                    .align(Alignment.Center),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Honda Civic Oriel 2024 Owners Deep Review - Pricing & Fuel Average", 
                        fontWeight = FontWeight.Bold, 
                        fontSize = 13.sp,
                        color = Color.Black
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Small video items
                    VideoListItem("Toyota Yaris Facelift 1.3L In Pakistan — Worth the Upgrade?", "https://images.unsplash.com/photo-1623998021451-31d864115160?w=150") {
                        viewModel.triggerToast("Playing Yaris Review...")
                    }
                    VideoListItem("Suzuki Alto VXL Daily Commute Average Road Test", "https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=150") {
                        viewModel.triggerToast("Playing Alto Commute...")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 11 - Latest News
                // ==========================================
                BrowseSectionTitle("Latest News") { onNavigateToPage("Blog") }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    NewsListItem(
                        title = "Fuel Prices Decrease Significantly across Pakistan",
                        date = "Today • 12:45 PM",
                        img = "https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=150"
                    ) { onNavigateToPage("Blog") }
                    NewsListItem(
                        title = "New Hyundai Elantra Variant Launched With Advanced Airbags",
                        date = "Yesterday • 04:31 PM",
                        img = "https://images.unsplash.com/photo-1623998021451-31d864115160?w=150"
                    ) { onNavigateToPage("Blog") }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 12 - Current Fuel Prices
                // ==========================================
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE2E7ED))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocalGasStation, contentDescription = "", tint = ShahOrange, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Current Fuel Prices", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
                        }
                        Text("Last updated May 31, 2026", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))

                        Spacer(modifier = Modifier.height(10.dp))

                        // Table header
                        Row(modifier = Modifier.fillMaxWidth().background(Color(0xFFF1F5F9)).padding(8.dp)) {
                            Text("Fuel Type", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f), fontSize = 12.sp)
                            Text("Price Per Liter", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End)
                        }

                        // Table Rows
                        FuelPriceRow("Petrol (Super)", "PKR 381.78")
                        FuelPriceRow("High Speed Diesel", "PKR 380.78")
                        FuelPriceRow("Light Speed Diesel", "PKR 159.76")
                        FuelPriceRow("CNG Region-I", "PKR 190.00")
                        FuelPriceRow("CNG Region-II", "PKR 190.00")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ==========================================
                // SECTION 13 - Browse More List
                // ==========================================
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .padding(16.dp)
                ) {
                    Text("Browse More", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
                    Spacer(modifier = Modifier.height(12.dp))

                    BrowseMoreItem("Forums", "Discuss everything on wheels") {
                        viewModel.triggerToast("Opening Forums...")
                    }
                    BrowseMoreItem("Blog", "Latest auto industry updates") {
                        onNavigateToPage("Blog")
                    }
                    BrowseMoreItem("New Car Prices", "Get latest price list") {
                        viewModel.resetFilters()
                        viewModel.minYear.value = 2025
                        onNavigateToListings("Cars", null)
                    }
                    BrowseMoreItem("Car Reviews", "Help find right car") {
                        onNavigateToPage("Videos")
                    }
                    BrowseMoreItem("Car Comparisons", "Compare specifications") {
                        viewModel.triggerToast("Comparing Toyota Corolla vs Honda Civic...")
                    }
                    BrowseMoreItem("Get on road price", "Know final price") {
                        viewModel.triggerToast("Final on-road price calculation active!")
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

// Subcomponents
@Composable
fun PillHeaderTab(
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isActive) Color(0xFF0F2C4C) else Color.Transparent)
            .border(1.dp, if (isActive) Color.Transparent else Color.White, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

@Composable
fun BrowseSectionTitle(
    title: String,
    showAction: Boolean = true,
    onActionClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            fontSize = 16.sp
        )
        if (showAction) {
            Text(
                "View All",
                color = Color(0xFF1B3F6B),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.clickable { onActionClick() }
            )
        }
    }
}

@Composable
fun CategoryRow(
    items: List<Pair<String, androidx.compose.ui.graphics.vector.ImageVector>>,
    onCellClick: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { (name, icon) ->
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onCellClick(name) },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFECEFF3))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, contentDescription = name, tint = Color(0xFF1B3F6B), modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(name, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, color = Color.Black, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun TwoColumnListings(
    listings: List<Listing>,
    onNavigateToDetail: (Int) -> Unit,
    forceCertified: Boolean = false
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        val chunked = listings.chunked(2)
        chunked.forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowItems.forEach { listing ->
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToDetail(listing.id) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column {
                            Box {
                                val img = listing.imagesList.firstOrNull() ?: "https://images.unsplash.com/photo-1623998021451-31d864115160?w=600"
                                AsyncImage(
                                    model = img,
                                    contentDescription = "",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                )
                                // Bookmark / Star on top left
                                Box(
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .size(24.dp)
                                        .background(Color.White.copy(alpha = 0.8f), CircleShape)
                                        .align(Alignment.TopStart),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = "", tint = ShahOrange, modifier = Modifier.size(14.dp))
                                }

                                if (forceCertified || listing.id % 2 == 1) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(6.dp)
                                            .background(Color(0xFF1B3F6B), RoundedCornerShape(3.dp))
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text("CERTIFIED", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("${listing.make} ${listing.model} ${listing.year}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(formatPricePkr(listing.price), color = Color(0xFF1B3F6B), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(listing.city, color = Color.Gray, fontSize = 10.sp)
                                Text("${listing.year} | 48,000 KM | ${listing.fuelType}", color = Color.Gray, fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }
                if (rowItems.size < 2) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
fun VideoListItem(
    title: String,
    thumbnail: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(70.dp).clip(RoundedCornerShape(6.dp))) {
            AsyncImage(model = thumbnail, contentDescription = "", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(
                modifier = Modifier.size(24.dp).background(Color.Black.copy(alpha = 0.5f), CircleShape).align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "", tint = Color.White, modifier = Modifier.size(12.dp))
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun NewsListItem(
    title: String,
    date: String,
    img: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = img, 
            contentDescription = "", 
            contentScale = ContentScale.Crop, 
            modifier = Modifier.size(70.dp).clip(RoundedCornerShape(6.dp))
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(date, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun FuelPriceRow(fuel: String, price: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(fuel, fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Medium)
        Text(price, fontSize = 12.sp, color = Color.DarkGray, fontWeight = FontWeight.Bold)
    }
    Divider(color = Color(0xFFF1F5F9))
}

@Composable
fun BrowseMoreItem(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            Text(subtitle, fontSize = 11.sp, color = Color.Gray)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = "", tint = Color.LightGray, modifier = Modifier.size(18.dp))
    }
    Divider(color = Color(0xFFECEFF3))
}

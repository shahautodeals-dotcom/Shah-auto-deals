package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Listing
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.flow.first

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToDetail: (Int) -> Unit
) {
    val context = LocalContext.current
    val listingState by viewModel.selectedListing.collectAsState()
    val allListings by viewModel.listings.collectAsState()
    val userSession by viewModel.currentUser.collectAsState()

    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("") }

    var showChatDialog by remember { mutableStateOf(false) }
    var chatMessageText by remember { mutableStateOf("") }

    val listing = listingState
    if (listing == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(10.dp))
                Text("Loading details...")
            }
        }
        return
    }

    // Is listing favorite state
    var isFav by remember { mutableStateOf(false) }
    LaunchedEffect(listing.id, userSession) {
        viewModel.isListingFavorite(listing.id).collect {
            isFav = it
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${listing.make} ${listing.model}", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Save Favorite button
                    IconButton(
                        onClick = {
                            viewModel.toggleFavorite(listing.id)
                            isFav = !isFav
                        },
                        modifier = Modifier.testTag("save_favorites_button")
                    ) {
                        Icon(
                            imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFav) Color.Red else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Share button
                    IconButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Shah Auto Deals listing")
                            putExtra(Intent.EXTRA_TEXT, "Check out this ${listing.make} ${listing.model} (${listing.year}) for ${formatPricePkr(listing.price)} on Shah Auto Deals!\nContact: ${listing.sellerPhone}")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Listing"))
                    }) {
                        Icon(Icons.Default.Share, contentDescription = "Share")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. Multiple image gallery with swiping indicators
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .background(Color.Black)
            ) {
                val images = listing.imagesList
                if (images.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.DirectionsCar, contentDescription = "Car", tint = Color.DarkGray, modifier = Modifier.size(64.dp))
                    }
                } else {
                    LazyRow(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(1.dp)
                    ) {
                        items(images) { imageUrl ->
                            AsyncImage(
                                model = imageUrl,
                                contentDescription = "Car Detail Image",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillParentMaxWidth()
                                    .fillMaxHeight()
                            )
                        }
                    }
                }

                // Featured/Visual indicator
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "1 / ${images.size.coerceAtLeast(1)} photos",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // 2. Headings & PKR formatting
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${listing.make} ${listing.model} ${listing.year}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = "City", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = listing.city,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Icon(Icons.Default.Visibility, contentDescription = "Views", tint = Color.Gray, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${listing.viewsCount} views",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text(
                        text = formatPricePkr(listing.price),
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.End
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Quick buttons: Whatsapp, Call, Chat
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // WhatsApp
                    Button(
                        onClick = {
                            val whatsappIntent = Intent(Intent.ACTION_VIEW).apply {
                                data = Uri.parse("https://api.whatsapp.com/send?phone=92${listing.sellerPhone.removePrefix("0").replace(" ", "")}&text=Salam! I am interested in your listing: ${listing.make} ${listing.model} ${listing.year} on Shah Auto Deals. Is it still available?")
                            }
                            try {
                                context.startActivity(whatsappIntent)
                            } catch (e: Exception) {
                                viewModel.triggerToast("Could not open WhatsApp. Seller phone: ${listing.sellerPhone}")
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("whatsapp_seller_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)) // WhatsApp green
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "WhatsApp")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WhatsApp", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    // Native Call
                    Button(
                        onClick = {
                            val callIntent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:${listing.sellerPhone}")
                            }
                            context.startActivity(callIntent)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("call_seller_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Call")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Call Seller", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    // Inbox Chat
                    OutlinedButton(
                        onClick = {
                            if (userSession == null) {
                                viewModel.triggerToast("Please login first to chat.")
                            } else if (userSession?.id == listing.userId) {
                                viewModel.triggerToast("You cannot chat with yourself.")
                            } else {
                                showChatDialog = true
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Icon(Icons.Default.Message, contentDescription = "Chat")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Message", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 3. Complete Specs list table
                Text(
                    text = "Vehicle Specifications",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        val specs = mutableListOf(
                            "Transmission" to listing.transmission,
                            "Fuel Type" to listing.fuelType,
                            "Year" to listing.year.toString(),
                            "Color" to listing.color,
                            "Registration" to listing.registered
                        )

                        if (listing.category == "Cars") {
                            specs.add("Body Type" to listing.bodyType)
                            specs.add("Mileage" to "${listing.mileage} km")
                            specs.add("Engine Size" to "${listing.engineCc} cc")
                        } else if (listing.category == "Bikes") {
                            specs.add("Engine Size" to "${listing.engineCc} cc")
                        } else {
                            specs.add("Component Compatibility" to listing.compatibility)
                        }

                        specs.forEachIndexed { index, pair ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = pair.first, fontSize = 13.sp, color = Color.Gray)
                                Text(text = pair.second, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            if (index < specs.size - 1) {
                                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Selected Features list
                if (listing.featuresList.isNotEmpty()) {
                    Text(
                        text = "Key Features",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listing.featuresList.forEach { feat ->
                            Box(
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = "Check", tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(feat, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Description
                if (listing.description.isNotBlank()) {
                    Text(
                        text = "Seller's Comments",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = listing.description,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // 4. Seller Info Card
                Text(
                    text = "Seller Information",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = listing.sellerName.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(listing.sellerName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Member since 2024 • Verified Seller", fontSize = 11.sp, color = Color.Gray)
                        }

                        Icon(Icons.Default.VerifiedUser, contentDescription = "Verified tag", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 5. Pakistani Map Canvas Placeholder
                Text(
                    text = "Seller Location Map",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Styled Canvas simulating a highway route map
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(Color(0xFFE2E8F0)) // Background slate
                            
                            // Draw highway paths
                            drawLine(Color.White, start = androidx.compose.ui.geometry.Offset(0f, 150f), end = androidx.compose.ui.geometry.Offset(size.width, 250f), strokeWidth = 14f)
                            drawLine(Color.White, start = androidx.compose.ui.geometry.Offset(100f, 0f), end = androidx.compose.ui.geometry.Offset(150f, size.height), strokeWidth = 10f)
                            drawLine(Color(0xFFCBD5E1), start = androidx.compose.ui.geometry.Offset(0f, 0f), end = androidx.compose.ui.geometry.Offset(size.width, size.height), strokeWidth = 4f)
                        }

                        Column(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset(y = (-10).dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = "Pin", tint = Color.Red, modifier = Modifier.size(34.dp))
                            Box(
                                modifier = Modifier
                                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(listing.city, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 6. Report listing button
                TextButton(
                    onClick = { showReportDialog = true },
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .testTag("report_listing_button")
                ) {
                    Icon(Icons.Default.Flag, contentDescription = "Report", tint = Color.Red, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Report Fake Listing or Scammer", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                // 7. Similar Cars Section
                Spacer(modifier = Modifier.height(12.dp))
                val similar = allListings.filter { it.category == listing.category && it.id != listing.id && it.status == "Approved" }
                if (similar.isNotEmpty()) {
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Similar Recommendations",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(similar) { sim ->
                            Card(
                                modifier = Modifier
                                    .width(160.dp)
                                    .clickable { onNavigateToDetail(sim.id) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column {
                                    val simImg = sim.imagesList.firstOrNull() ?: ""
                                    AsyncImage(
                                        model = simImg,
                                        contentDescription = "",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(95.dp)
                                    )
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text(
                                            text = "${sim.make} ${sim.model}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = formatPricePkr(sim.price),
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // REPORT POPUP DIALOG
        if (showReportDialog) {
            AlertDialog(
                onDismissRequest = { showReportDialog = false },
                title = { Text("Report this ad", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Why are you reporting this ad? Admin will investigate.", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        val reasons = listOf("Counterfeit / Fake details", "Fraudulent seller / Advance payment demand", "Vehicle already sold", "Unethical / Spam language")
                        reasons.forEach { r ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { reportReason = r }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = reportReason == r, onClick = { reportReason = r })
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(r, fontSize = 13.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (reportReason.isNotBlank()) {
                                viewModel.submitReport(
                                    listingId = listing.id,
                                    reason = reportReason,
                                    listingTitle = "${listing.make} ${listing.model}"
                                )
                                showReportDialog = false
                            } else {
                                viewModel.triggerToast("Please select a reason.")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("Submit Report", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showReportDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // DIRECT CHAT DIALOG
        if (showChatDialog) {
            AlertDialog(
                onDismissRequest = { showChatDialog = false },
                title = { Text("Send Message to Seller", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Inquire about this vehicle instantly.", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = chatMessageText,
                            onValueChange = { chatMessageText = it },
                            placeholder = { Text("Assalam-o-ALaykum, is this car still available and negotiable?") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            maxLines = 4
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.sendMessage(
                                recipientId = listing.userId,
                                listingId = listing.id,
                                messageText = chatMessageText,
                                listingTitle = "${listing.make} ${listing.model}"
                            )
                            showChatDialog = false
                            chatMessageText = ""
                        }
                    ) {
                        Text("Send Message", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showChatDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand colors
val ShahBlue = Color(0xFF0D47A1) // Deep automotive blue
val ShahBlueLight = Color(0xFF42A5F5)
val ShahOrange = Color(0xFFFF6D00) // Crisp, sporty accent orange
val ShahWhite = Color(0xFFFAFAFA)

// Light theme color palette
val LightPrimary = Color(0xFF0F52BA)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightSecondary = Color(0xFF1E293B)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightTertiary = Color(0xFFFF6D00)
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF0F172A)

// Dark theme color palette
val DarkPrimary = Color(0xFF38BDF8)
val DarkOnPrimary = Color(0xFF0369A1)
val DarkSecondary = Color(0xFF64748B)
val DarkOnSecondary = Color(0xFFF1F5F9)
val DarkTertiary = Color(0xFFFF9E00)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF8FAFC)

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectBrandScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToListings: (category: String?, make: String?) -> Unit
) {
    val brands = listOf(
        "Toyota", "Suzuki", "Honda", "Aion", "Alektra", "Audi",
        "BAIC", "BAW", "BMW", "BYD", "Changan", "Chery",
        "Deepal", "Dongfeng", "Forthing", "GUGO", "Haval", 
        "Honri", "Hyptec", "Hyundai", "Inverex", "Isuzu", 
        "JAC", "Jaecoo", "Jetour", "JMEV", "JW Forland",
        "Kaiyi", "KIA", "Mercedes Benz", "MG", "MINI", "Nora",
        "Omoda", "ORA", "Peugeot", "Prince", "Riddara", "Seres",
        "Tank", "Xpeng", "Zeekr"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Select Brand", 
                        fontWeight = FontWeight.Bold, 
                        fontSize = 18.sp,
                        color = Color.White
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack, 
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1B3F6B)
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.White)
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(0.dp) // Exact clean grid with borders
            ) {
                items(brands) { brand ->
                    BrandGridCell(
                        brandName = brand,
                        onClick = {
                            viewModel.resetFilters()
                            viewModel.selectedMake.value = brand
                            onNavigateToListings(null, brand)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BrandGridCell(
    brandName: String,
    onClick: () -> Unit
) {
    // Exact copy of Pakwheels style 3-column layout with clean borders
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(0.5.dp, Color(0xFFE0E0E0)),
        shape = androidx.compose.ui.graphics.RectangleShape
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // High fidelity premium logo placeholder circle based on brand
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFFF0F4F8), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val monogramText = if (brandName.startsWith("Mercedes Benz")) "MB" else if (brandName.length >= 2) brandName.take(2).uppercase() else brandName.take(1).uppercase()
                Text(
                    text = monogramText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF1B3F6B)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = brandName,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color.Black,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreProfileScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToListings: (category: String?, make: String?) -> Unit,
    onNavigateToAuth: () -> Unit,
    onNavigateToPage: (String) -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    
    // Dynamic Name: if currentUser is in db utilize it, otherwise fallback to user's defined "Faizan Shah"
    val displayName = currentUser?.name ?: "Faizan Shah"
    val displayEmail = currentUser?.email ?: "faizan.shah@gmail.com"
    val avatarUrl = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"

    // Expandable Menu States
    var isActivityExpanded by remember { mutableStateOf(false) }
    var isAlertsExpanded by remember { mutableStateOf(false) }
    var isServicesExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1B3F6B)
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF5F7FA))
                .verticalScroll(rememberScrollState())
        ) {
            // Welcome Card Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar photo
                    AsyncImage(
                        model = avatarUrl,
                        contentDescription = "User Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color(0xFF1B3F6B), CircleShape)
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Welcome",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            displayName,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            displayEmail,
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }

                    Button(
                        onClick = {
                            if (currentUser == null) {
                                onNavigateToAuth()
                            } else {
                                viewModel.triggerToast("Viewing advanced profile settings...")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B3F6B)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Text(
                            if (currentUser == null) "Log In" else "View Profile", 
                            fontSize = 12.sp, 
                            color = Color.White
                        )
                    }
                }
            }

            // Get Verified Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE6F0FA)), // High-fidelity soft blue background
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFB3D1F2))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF1B3F6B), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = "",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Get Verified, Gain Trust",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B3F6B),
                                fontSize = 14.sp
                            )
                            Text(
                                "Increase credibility, get more genuine buyers",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Row(
                        modifier = Modifier
                            .clickable {
                                viewModel.triggerToast("Submit verification request to backend servers!")
                            }
                            .align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Verify Now",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B3F6B),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "",
                            tint = Color(0xFF1B3F6B),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // PERSONAL SECTION
            ProfileCategoryTitle("PERSONAL SECTION")
            
            // My Activity Dropdown
            ProfileMenuItem(
                title = "My Activity",
                icon = Icons.Default.History,
                hasDropdown = true,
                isExpanded = isActivityExpanded,
                onClick = { isActivityExpanded = !isActivityExpanded }
            )
            AnimatedVisibility(visible = isActivityExpanded) {
                Column(modifier = Modifier.background(Color(0xFFFCFDFF))) {
                    ProfileSubMenuItem("My Listings", Icons.Default.DirectionsCar) {
                        viewModel.resetFilters()
                        onNavigateToListings(null, null)
                    }
                    ProfileSubMenuItem("Saved Ads & Searches", Icons.Default.BookmarkBorder) {
                        viewModel.triggerToast("Opened saved properties")
                    }
                }
            }
            
            ProfileMenuItem(
                title = "My Credits",
                icon = Icons.Default.MonetizationOn,
                onClick = { viewModel.triggerToast("Credits balance: 500 Coins") }
            )
            
            // Alerts Dropdown
            ProfileMenuItem(
                title = "Alerts",
                icon = Icons.Default.NotificationsActive,
                hasDropdown = true,
                isExpanded = isAlertsExpanded,
                onClick = { isAlertsExpanded = !isAlertsExpanded }
            )
            AnimatedVisibility(visible = isAlertsExpanded) {
                Column(modifier = Modifier.background(Color(0xFFFCFDFF))) {
                    ProfileSubMenuItem("Saved Alerts", Icons.Default.NotificationAdd) {
                        viewModel.triggerToast("Alert set for Toyota Corolla 2021")
                    }
                }
            }
            
            ProfileMenuItem(
                title = "Notifications",
                icon = Icons.Default.Notifications,
                onClick = { viewModel.triggerToast("Checking notifications box...") }
            )
            
            ProfileMenuItem(
                title = "Theme (Dark/Light)",
                icon = Icons.Default.Palette,
                onClick = { viewModel.triggerToast("Material 3 Dynamic System Sync Active") }
            )
            
            ProfileMenuItem(
                title = "Choose Language",
                icon = Icons.Default.Language,
                onClick = { viewModel.triggerToast("Language option: English / Urdu") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // PRODUCTS SECTION
            ProfileCategoryTitle("PRODUCTS SECTION")
            ProfileMenuItem("Sell My Car", Icons.Default.AddCircle, onClick = {
                if (currentUser == null) {
                    onNavigateToAuth()
                } else {
                    viewModel.resetPostAdForm()
                    viewModel.formCategory.value = "Cars"
                    viewModel.triggerToast("Opening selling form...")
                    // Switch to selling screen in MainApp Content
                }
            })
            
            ProfileMenuItem("Buy Used Car", Icons.Default.DirectionsCar, onClick = {
                viewModel.resetFilters()
                viewModel.selectedCategory.value = "Cars"
                onNavigateToListings("Cars", null)
            })
            
            ProfileMenuItem("New Cars", Icons.Default.DirectionsCar, onClick = {
                viewModel.resetFilters()
                viewModel.selectedCategory.value = "Cars"
                viewModel.minYear.value = 2025
                onNavigateToListings("Cars", null)
            })
            
            ProfileMenuItem("Order Car Inspection", Icons.Default.Search, onClick = {
                viewModel.triggerToast("Initiated Car Inspection Request!")
            })
            
            // Auto Services Dropdown
            ProfileMenuItem(
                title = "Auto Services",
                icon = Icons.Default.Handyman,
                hasDropdown = true,
                isExpanded = isServicesExpanded,
                onClick = { isServicesExpanded = !isServicesExpanded }
            )
            AnimatedVisibility(visible = isServicesExpanded) {
                Column(modifier = Modifier.background(Color(0xFFFCFDFF))) {
                    ProfileSubMenuItem("Car Insurance", Icons.Default.Shield) {
                        viewModel.triggerToast("Redirecting to Insurance partners")
                    }
                    ProfileSubMenuItem("Car Finance", Icons.Default.LocalActivity) {
                        viewModel.triggerToast("Checking banks interest rates")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // EXPLORE SECTION
            ProfileCategoryTitle("EXPLORE SECTION")
            ProfileMenuItem("Blog & Articles", Icons.Default.Book, onClick = { onNavigateToPage("Blog") })
            ProfileMenuItem("Videos & Reviews", Icons.Default.VideoLibrary, onClick = { onNavigateToPage("Videos") })
            ProfileMenuItem("Cool Rides Showcase", Icons.Default.LocalFireDepartment, onClick = { viewModel.triggerToast("Viewing community rides") })

            Spacer(modifier = Modifier.height(20.dp))

            // Logout Option
            if (currentUser != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clickable { viewModel.logout() },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "", tint = Color.Red)
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("Log Out Account", fontWeight = FontWeight.Bold, color = Color.Red, fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Footers
            Text(
                "Need help? Contact Us",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B3F6B),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToPage("Contact Us") },
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(10.dp))
            
            Text(
                "Shah Auto Deals",
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 15.sp
            )
            Text(
                "Version v4.2.0 (Official Build)",
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun ProfileCategoryTitle(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color.Gray,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun ProfileMenuItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    hasDropdown: Boolean = false,
    isExpanded: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = "", tint = Color(0xFF1B3F6B), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                title,
                fontSize = 14.sp,
                color = Color.Black,
                fontWeight = FontWeight.Medium
            )
        }
        
        if (hasDropdown) {
            Icon(
                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = "",
                tint = Color.Gray,
                modifier = Modifier.size(18.dp)
            )
        } else {
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "",
                tint = Color.LightGray,
                modifier = Modifier.size(18.dp)
            )
        }
    }
    Divider(color = Color(0xFFF0F2F5))
}

@Composable
fun ProfileSubMenuItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(start = 48.dp, end = 16.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = "", tint = ShahOrange, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            title,
            fontSize = 13.sp,
            color = Color.DarkGray
        )
    }
    Divider(color = Color(0xFFF5F7FA))
}

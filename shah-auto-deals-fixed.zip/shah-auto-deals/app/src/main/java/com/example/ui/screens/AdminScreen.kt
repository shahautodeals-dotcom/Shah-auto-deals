package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Listing
import com.example.data.Report
import com.example.data.User
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToDetail: (Int) -> Unit
) {
    val currentUserSession by viewModel.currentUser.collectAsState()
    val allPlatformUsers by viewModel.allUsers.collectAsState()
    val allPlatformListings by viewModel.allAdminListings.collectAsState()
    val reportsList by viewModel.allReports.collectAsState()

    var adminSectionTab by remember { mutableStateOf("Stats") } // Stats, Ads Moderation, Users, Reports

    // Private Admin Gate
    val isAdmin = currentUserSession?.role == "admin"
    if (!isAdmin) {
        var adminEmail by remember { mutableStateOf("admin@shahautodeals.com") }
        var adminPassword by remember { mutableStateOf("admin123") }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_login_box"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("Admin Portal Private Sign In", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Enter administrator credentials to moderate listings.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = adminEmail,
                        onValueChange = { adminEmail = it },
                        label = { Text("Admin Email") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = adminPassword,
                        onValueChange = { adminPassword = it },
                        label = { Text("Admin Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            viewModel.login(adminEmail, adminPassword) {
                                viewModel.triggerToast("Welcome administrator!")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Connect Admin Dashboard", color = Color.White)
                    }
                }
            }
        }
        return
    }

    // AUTHENTICATED ADMIN PANEL LAYOUT
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard Portal", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Horizontal row subtabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(vertical = 8.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val adminTabs = listOf("Stats", "Ads Moderation", "Users", "Reports")
                adminTabs.forEach { tab ->
                    val isSel = adminSectionTab == tab
                    FilterChip(
                        selected = isSel,
                        onClick = { adminSectionTab = tab },
                        label = { Text(tab, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant)

            // Dynamic panel
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (adminSectionTab) {
                    "Stats" -> AdminStatsOverview(allPlatformUsers, allPlatformListings, reportsList)
                    "Ads Moderation" -> AdminAdsModeration(allPlatformListings, viewModel, onNavigateToDetail)
                    "Users" -> AdminUsersSection(allPlatformUsers, viewModel)
                    "Reports" -> AdminReportsSection(reportsList, viewModel)
                }
            }
        }
    }
}

// PARTS COMPONENT: STATS OVERVIEW
@Composable
fun AdminStatsOverview(
    users: List<User>,
    listings: List<Listing>,
    reports: List<Report>
) {
    val scrollState = rememberScrollState()
    val boostedCount = listings.count { it.featured }
    val pendingCount = listings.count { it.status == "Pending" }
    
    // Revenue simulation: Each boosted ad costs PKR 5,000 listing fee
    val simulatedRevenue = boostedCount * 5000.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Platform Analytics", fontSize = 16.sp, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MiniStatCard(label = "Total Users", count = users.size.toString(), icon = Icons.Default.People, modifier = Modifier.weight(1f))
            MiniStatCard(label = "Platform Ads", count = listings.size.toString(), icon = Icons.Default.DirectionsCar, modifier = Modifier.weight(1f))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MiniStatCard(label = "Premium Boosts", count = boostedCount.toString(), icon = Icons.Default.ElectricBolt, modifier = Modifier.weight(1f))
            MiniStatCard(label = "Pending Moderations", count = pendingCount.toString(), icon = Icons.Default.PendingActions, modifier = Modifier.weight(1f))
        }

        // Revenue Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Simulated Boost Revenue", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(
                    text = formatPricePkr(simulatedRevenue),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("Calculated from PKR 5,000 fee per Boosted advertisement.", fontSize = 10.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun MiniStatCard(
    label: String,
    count: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, fontSize = 12.sp, color = Color.Gray)
                Icon(imageVector = icon, contentDescription = "", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(count, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

// PARTS COMPONENT: ADS MODERATION
@Composable
fun AdminAdsModeration(
    listings: List<Listing>,
    viewModel: AppViewModel,
    onNavigateToDetail: (Int) -> Unit
) {
    if (listings.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No listings on platform.")
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(listings) { listing ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row {
                            AsyncImage(
                                model = listing.imagesList.firstOrNull() ?: "",
                                contentDescription = "",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(60.dp).clip(RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${listing.make} ${listing.model} (${listing.year})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Seller: ${listing.sellerName} (${listing.sellerPhone})", fontSize = 11.sp, color = Color.Gray)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Status: ", fontSize = 11.sp)
                                    Text(listing.status, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (listing.status == "Approved") Color(0xFF2E7D32) else ShahOrange)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onNavigateToDetail(listing.id) }) {
                                Text("Inspect", fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))

                            if (listing.status != "Approved") {
                                Button(
                                    onClick = { viewModel.adminApprove(listing) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                    modifier = Modifier.height(34.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp)
                                ) {
                                    Text("Approve", fontSize = 11.sp, color = Color.White)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            if (listing.status != "Rejected") {
                                OutlinedButton(
                                    onClick = { viewModel.adminReject(listing) },
                                    modifier = Modifier.height(34.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp)
                                ) {
                                    Text("Reject", fontSize = 11.sp, color = Color.Red)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            IconButton(onClick = { viewModel.adminDeleteListing(listing) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// PARTS COMPONENT: USERS LIST
@Composable
fun AdminUsersSection(
    users: List<User>,
    viewModel: AppViewModel
) {
    if (users.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No users signed up.")
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(users) { u ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(18.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(u.name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(u.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${u.email} • ${u.phone}", fontSize = 11.sp, color = Color.Gray)
                            Text("Role: ${u.role.uppercase()} • City: ${u.city}", fontSize = 11.sp, color = Color.Gray)
                        }

                        if (u.role != "admin") {
                            IconButton(onClick = { viewModel.adminBanUser(u) }) {
                                Icon(Icons.Default.Block, contentDescription = "Ban User", tint = Color.Red)
                            }
                        }
                    }
                }
            }
        }
    }
}

// PARTS COMPONENT: REPORTS MODERATION
@Composable
fun AdminReportsSection(
    reports: List<Report>,
    viewModel: AppViewModel
) {
    val activeReports = reports.filter { it.status == "Pending" }
    if (activeReports.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Clean logs! No pending complaints.", fontWeight = FontWeight.SemiBold, color = Color.Gray)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(activeReports) { r ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Complainant: ${r.reporterName}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Pending Alert", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Re listing: ${r.listingTitle}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Stated Reason: \"${r.reason}\"", fontSize = 12.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { viewModel.adminResolveReport(r, deleteContent = false) }) {
                                Text("Dismiss", color = Color.Gray, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { viewModel.adminResolveReport(r, deleteContent = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                modifier = Modifier.height(34.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp)
                            ) {
                                Text("Delete Content", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        var showSplash by remember { mutableStateOf(true) }

        LaunchedEffect(Unit) {
          delay(300) // Fast loading splash transition
          showSplash = false
        }

        if (showSplash) {
          SplashScreenContent()
        } else {
          MainAppContent()
        }
      }
    }
  }
}

@Composable
fun SplashScreenContent() {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF1B3F6B)), // Exact deep blue brand bg
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(90.dp)
          .clip(CircleShape)
          .background(Color.White.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.DirectionsCar,
          contentDescription = "Shah Auto Deals Car Logo Icon",
          tint = Color(0xFFF37021), // Exact brand orange
          modifier = Modifier.size(54.dp)
        )
      }
      
      Spacer(modifier = Modifier.height(20.dp))
      
      Text(
        text = "Shah Auto Deals",
        fontWeight = FontWeight.Black,
        color = Color.White,
        fontSize = 28.sp,
        letterSpacing = 1.sp
      )
      
      Spacer(modifier = Modifier.height(6.dp))
      
      Text(
        text = "Pakistan's Trusted Auto Marketplace",
        color = Color(0xFFE2E7ED),
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium
      )
      
      Spacer(modifier = Modifier.height(40.dp))
      
      CircularProgressIndicator(
        color = Color(0xFFF37021),
        strokeWidth = 3.dp,
        modifier = Modifier.size(28.dp)
      )
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent() {
  val context = LocalContext.current
  val navController = rememberNavController()
  val viewModel: AppViewModel = viewModel()
  
  val userSession by viewModel.currentUser.collectAsState()
  val activeDashboardTab by viewModel.activeDashboardTab.collectAsState()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  var showSellBottomSheet by remember { mutableStateOf(false) }

  // Native Toast Display Observer
  LaunchedEffect(key1 = true) {
    viewModel.toastMessage.collect { msg ->
      Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }
  }

  // Determine standard Bottom Navigation visibility — Hide on details or auth
  val displayBottomNav = currentRoute != null && 
          !currentRoute.startsWith("detail") && 
          !currentRoute.startsWith("auth") && 
          !currentRoute.startsWith("additional") &&
          !currentRoute.startsWith("search") &&
          !currentRoute.startsWith("select_brand")

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    bottomBar = {
      if (displayBottomNav) {
        // EXACT FIXED BOTTOM NAVIGATION (5 Tabs matching Specifications)
        NavigationBar(
          containerColor = Color.White,
          tonalElevation = 8.dp
        ) {
          // Tab 1: Home icon
          NavigationBarItem(
            selected = currentRoute == "home",
            onClick = {
              navController.navigate("home") {
                popUpTo("home") { saveState = true }
                launchSingleTop = true
                restoreState = true
              }
            },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color(0xFF1B3F6B),
              selectedTextColor = Color(0xFF1B3F6B),
              indicatorColor = Color(0xFFF0F4F8)
            )
          )

          // Tab 2: My Ads icon
          NavigationBarItem(
            selected = currentRoute == "dashboard" && activeDashboardTab == "My Ads",
            onClick = {
              if (userSession == null) {
                navController.navigate("auth")
              } else {
                viewModel.activeDashboardTab.value = "My Ads"
                navController.navigate("dashboard") {
                  popUpTo("home") { saveState = true }
                  launchSingleTop = true
                  restoreState = true
                }
              }
            },
            icon = { Icon(Icons.Default.DirectionsCar, contentDescription = "My Ads") },
            label = { Text("My Ads", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color(0xFF1B3F6B),
              selectedTextColor = Color(0xFF1B3F6B),
              indicatorColor = Color(0xFFF0F4F8)
            )
          )

          // Tab 3: + SELL NOW (blue elevated circle center action button)
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight(),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
              modifier = Modifier
                .fillMaxHeight()
                .clickable { showSellBottomSheet = true }
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .background(Color(0xFF1B3F6B), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = "Sell Now Plus Action",
                  tint = Color.White,
                  modifier = Modifier.size(24.dp)
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                "SELL NOW",
                fontSize = 9.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF1B3F6B)
              )
            }
          }

          // Tab 4: Chat icon (links to Dashboard inbox chats section)
          NavigationBarItem(
            selected = currentRoute == "dashboard" && activeDashboardTab == "Inbox",
            onClick = {
              if (userSession == null) {
                navController.navigate("auth")
              } else {
                viewModel.activeDashboardTab.value = "Inbox"
                navController.navigate("dashboard") {
                  popUpTo("home") { saveState = true }
                  launchSingleTop = true
                  restoreState = true
                }
              }
            },
            icon = { Icon(Icons.Default.Chat, contentDescription = "Inbox Chats") },
            label = { Text("Chat", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color(0xFF1B3F6B),
              selectedTextColor = Color(0xFF1B3F6B),
              indicatorColor = Color(0xFFF0F4F8)
            )
          )

          // Tab 5: More dots icon (triggers More/Profile Screen description)
          NavigationBarItem(
            selected = currentRoute == "more_profile",
            onClick = {
              navController.navigate("more_profile") {
                popUpTo("home") { saveState = true }
                launchSingleTop = true
                restoreState = true
              }
            },
            icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "More Settings") },
            label = { Text("More", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color(0xFF1B3F6B),
              selectedTextColor = Color(0xFF1B3F6B),
              indicatorColor = Color(0xFFF0F4F8)
            )
          )
        }
      }
    }
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = "home",
      modifier = Modifier.padding(innerPadding)
    ) {
      // route: Home with all 13 sub-sections structured elegantly
      composable("home") {
        HomeScreen(
          viewModel = viewModel,
          onNavigateToListings = { category, make ->
            navController.navigate("listings?category=$category&make=$make")
          },
          onNavigateToDetail = { id ->
            navController.navigate("detail/$id")
          },
          onNavigateToPage = { name ->
            navController.navigate("additional/$name")
          },
          onNavigateToSelectBrand = {
            navController.navigate("select_brand")
          },
          onNavigateToSearch = {
            navController.navigate("search")
          }
        )
      }

      // route: Select Brand UI matching grid table with search binding
      composable("select_brand") {
        SelectBrandScreen(
          viewModel = viewModel,
          onNavigateBack = { navController.popBackStack() },
          onNavigateToListings = { category, make ->
            navController.navigate("listings?category=$category&make=$make")
          }
        )
      }

      // route: Search UI matching history caches, models list and linkups
      composable("search") {
        SearchScreen(
          viewModel = viewModel,
          onNavigateBack = { navController.popBackStack() },
          onNavigateToListings = { category, make ->
            navController.navigate("listings?category=$category&make=$make")
          }
        )
      }

      // route: Profile and details screen replacing flat navigations
      composable("more_profile") {
        MoreProfileScreen(
          viewModel = viewModel,
          onNavigateBack = { navController.popBackStack() },
          onNavigateToListings = { category, make ->
            navController.navigate("listings?category=$category&make=$make")
          },
          onNavigateToAuth = {
            navController.navigate("auth")
          },
          onNavigateToPage = { name ->
            navController.navigate("additional/$name")
          }
        )
      }

      // route: Listings with optional category and make arg queries
      composable(
        route = "listings?category={category}&make={make}",
        arguments = listOf(
          navArgument("category") { 
            type = NavType.StringType
            nullable = true
            defaultValue = null
          },
          navArgument("make") {
            type = NavType.StringType
            nullable = true
            defaultValue = null
          }
        )
      ) { backStackEntry ->
        val catArg = backStackEntry.arguments?.getString("category")
        val makeArg = backStackEntry.arguments?.getString("make")

        // Sync ViewModel filters based on deep navigation args
        LaunchedEffect(catArg, makeArg) {
          if (catArg != null) {
            viewModel.selectedCategory.value = catArg
          }
          if (makeArg != null) {
            viewModel.selectedMake.value = makeArg
          }
        }

        ListingsScreen(
          viewModel = viewModel,
          onNavigateToDetail = { id ->
            navController.navigate("detail/$id")
          }
        )
      }

      // route: Detail with dynamic listing id
      composable(
        route = "detail/{id}",
        arguments = listOf(navArgument("id") { type = NavType.IntType })
      ) { backStackEntry ->
        val listingId = backStackEntry.arguments?.getInt("id") ?: 0
        
        LaunchedEffect(listingId) {
          viewModel.getListingById(listingId)?.let {
            viewModel.viewListingDetail(it)
          }
        }

        DetailScreen(
          viewModel = viewModel,
          onNavigateBack = {
            navController.popBackStack()
          },
          onNavigateToDetail = { id ->
            navController.navigate("detail/$id") {
              popUpTo("home")
            }
          }
        )
      }

      // route: Multistep selling ad form
      composable("post_ad") {
        PostAdScreen(
          viewModel = viewModel,
          onNavigateToAuth = {
            navController.navigate("auth")
          },
          onNavigateToMyAds = {
            viewModel.activeDashboardTab.value = "My Ads"
            navController.navigate("dashboard") {
              popUpTo("home")
            }
          }
        )
      }

      // route: Onboarding authentication screen
      composable("auth") {
        AuthScreen(
          viewModel = viewModel,
          onAuthSuccess = {
            viewModel.activeDashboardTab.value = "My Ads"
            navController.navigate("dashboard") {
              popUpTo("home")
            }
          }
        )
      }

      // route: Dashboard screen carrying profile, favorites & chats
      composable("dashboard") {
        DashboardScreen(
          viewModel = viewModel,
          onNavigateToDetail = { id ->
            navController.navigate("detail/$id")
          },
          onNavigateBack = {
            navController.popBackStack()
          }
        )
      }

      // route: Admin portal login and moderations list
      composable("admin") {
        AdminScreen(
          viewModel = viewModel,
          onNavigateBack = {
            navController.popBackStack()
          },
          onNavigateToDetail = { id ->
            navController.navigate("detail/$id")
          }
        )
      }

      // route: Dynamic details for auxiliary help pages
      composable(
        route = "additional/{page}",
        arguments = listOf(navArgument("page") { type = NavType.StringType })
      ) { backStackEntry ->
        val pName = backStackEntry.arguments?.getString("page") ?: "About Us"
        AdditionalScreen(
          pageName = pName,
          viewModel = viewModel,
          onNavigateBack = {
            navController.popBackStack()
          }
        )
      }
    }
  }

  // ==========================================
  // SELL NOW CHOICE POPUP (Modal Bottom Sheet)
  // ==========================================
  if (showSellBottomSheet) {
    ModalBottomSheet(
      onDismissRequest = { showSellBottomSheet = false },
      dragHandle = null,
      containerColor = Color.White,
      shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 24.dp)
      ) {
        // Flat header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "What do you want to sell?",
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
            color = Color.Black
          )
          IconButton(onClick = { showSellBottomSheet = false }) {
            Icon(Icons.Outlined.Close, contentDescription = "Close Sell Now Dialog", tint = Color.Gray)
          }
        }

        Divider(color = Color(0xFFF1F5F9))

        Spacer(modifier = Modifier.height(16.dp))

        // Row of 3 options: Car | Bike | Auto Parts
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically
        ) {
          SellPopupItem(
            label = "Car",
            icon = Icons.Default.DirectionsCar,
            onClick = {
              showSellBottomSheet = false
              viewModel.resetPostAdForm()
              viewModel.formCategory.value = "Cars"
              if (userSession == null) {
                navController.navigate("auth")
              } else {
                navController.navigate("post_ad")
              }
            }
          )

          SellPopupItem(
            label = "Bike",
            icon = Icons.Default.TwoWheeler,
            onClick = {
              showSellBottomSheet = false
              viewModel.resetPostAdForm()
              viewModel.formCategory.value = "Bikes"
              if (userSession == null) {
                navController.navigate("auth")
              } else {
                navController.navigate("post_ad")
              }
            }
          )

          SellPopupItem(
            label = "Parts",
            icon = Icons.Default.Settings,
            onClick = {
              showSellBottomSheet = false
              viewModel.resetPostAdForm()
              viewModel.formCategory.value = "Auto Parts"
              if (userSession == null) {
                navController.navigate("auth")
              } else {
                navController.navigate("post_ad")
              }
            }
          )
        }
      }
    }
  }
}

@Composable
fun SellPopupItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .background(Color(0xFFF0F4F8), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color(0xFF1B3F6B),
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            fontSize = 13.sp
        )
    }
}

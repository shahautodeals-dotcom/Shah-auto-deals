package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToListings: (category: String?, make: String?) -> Unit
) {
    var searchInput by remember { mutableStateOf("") }
    val popularMakes = listOf(
        "Toyota", "Suzuki", "Honda", "Daihatsu", "KIA", 
        "Hyundai", "Nissan", "Haval", "Changan", "MG"
    )

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B3F6B))
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack, 
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                
                TextField(
                    value = searchInput,
                    onValueChange = { searchInput = it },
                    placeholder = { Text("Search used cars...", color = Color.Gray, fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        disabledContainerColor = Color.White,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    singleLine = true
                )
                
                TextButton(
                    onClick = {
                        viewModel.resetFilters()
                        viewModel.searchQuery.value = searchInput
                        onNavigateToListings(null, null)
                    }
                ) {
                    Text("Search", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF7F9FC))
        ) {
            // Recent Searches section
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Recent Searches",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        fontSize = 15.sp
                    )
                    Text(
                        "View All", 
                        color = Color(0xFF1B3F6B),
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        modifier = Modifier.clickable {
                            viewModel.resetFilters()
                            viewModel.selectedMake.value = "Hyundai"
                            viewModel.selectedModel.value = "Elantra"
                            viewModel.selectedCity.value = "Karachi"
                            onNavigateToListings(null, "Hyundai")
                        }
                    )
                }
                
                // Specific search card requested: "Hyundai Elantra, Karachi, Any Price, 2022-2022"
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clickable {
                            viewModel.resetFilters()
                            viewModel.selectedMake.value = "Hyundai"
                            viewModel.selectedModel.value = "Elantra"
                            viewModel.selectedCity.value = "Karachi"
                            viewModel.minYear.value = 2022
                            viewModel.maxYear.value = 2022
                            onNavigateToListings(null, "Hyundai")
                        },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.History, 
                            contentDescription = "Recent search history",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "Hyundai Elantra", 
                                fontWeight = FontWeight.Bold, 
                                fontSize = 14.sp,
                                color = Color.Black
                            )
                            Text(
                                "Karachi • Any Price • 2022 - 2022", 
                                fontSize = 12.sp, 
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // Advanced Search Anchor Button
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Advanced Search",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B3F6B),
                        fontSize = 14.sp,
                        modifier = Modifier
                            .clickable {
                                viewModel.resetFilters()
                                onNavigateToListings(null, null)
                            }
                            .background(Color(0xFFE6F0FA), RoundedCornerShape(20.dp))
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                    )
                }
            }

            // Popular Used Cars Title
            item {
                Text(
                    "Popular Used Cars",
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }

            // Popular makes list
            items(popularMakes) { make ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .clickable {
                            viewModel.resetFilters()
                            viewModel.selectedMake.value = make
                            onNavigateToListings(null, make)
                        }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, contentDescription = "", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = make,
                            fontSize = 14.sp,
                            color = Color.Black,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight, 
                        contentDescription = "Select", 
                        tint = Color.LightGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Divider(color = Color(0xFFF0F2F5))
            }
        }
    }
}

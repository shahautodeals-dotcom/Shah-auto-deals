package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        User::class,
        Listing::class,
        Favorite::class,
        Message::class,
        Report::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun messageDao(): MessageDao
    abstract fun reportDao(): ReportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shah_auto_deals_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        // Prepopulate database with realistic dummy listings and admin/user roles
        suspend fun prepopulate(db: AppDatabase) {
            val userDao = db.userDao()
            val listingDao = db.listingDao()

            // Check if we already have cars or users
            if (listingDao.getListingsCount() > 0) {
                return
            }

            // Create admin and common users
            val adminId = userDao.insertUser(
                User(
                    name = "Shah Raza",
                    email = "admin@shahautodeals.com",
                    phone = "03001234567",
                    city = "Lahore",
                    role = "admin",
                    avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150",
                    passwordHash = "admin123"
                )
            ).toInt()

            val seller1Id = userDao.insertUser(
                User(
                    name = "Bilal Khan",
                    email = "bilal@yahoo.com",
                    phone = "03217654321",
                    city = "Karachi",
                    role = "user",
                    avatarUrl = "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=150",
                    passwordHash = "user123"
                )
            ).toInt()

            val seller2Id = userDao.insertUser(
                User(
                    name = "Fatima Malik",
                    email = "fatima@gmail.com",
                    phone = "03139876543",
                    city = "Islamabad",
                    role = "user",
                    avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
                    passwordHash = "user123"
                )
            ).toInt()

            // Create mock Listings (Cars)
            val corollaImages = "https://images.unsplash.com/photo-1621008080185-a1c89027477a?w=600,https://images.unsplash.com/photo-1623998021451-31d864115160?w=600"
            val civicImages = "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=600,https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=600"
            val sportageImages = "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=600,https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=600"
            val altoImages = "https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?w=600,https://images.unsplash.com/photo-1525609004556-c46c7d6cf0a3?w=600"

            val ybrImages = "https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600"
            val cd70Images = "https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=600"

            val alloyImages = "https://images.unsplash.com/photo-1611245329358-ac82f8c51f4c?w=600"
            val androidPlayerImages = "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=600"

            // Insert Cars
            listingDao.insertListing(
                Listing(
                    userId = seller1Id,
                    category = "Cars",
                    make = "Toyota",
                    model = "Corolla",
                    year = 2021,
                    price = 4850000.0, // 48.5 Lakhs
                    city = "Lahore",
                    description = "Toyota Corolla Altis Grande 1.8 in pristine condition. Single handedly driven, bumper to bumper genuine, standard dealership maintenance history. High fuel economy and dual VVTI engine.",
                    status = "Approved",
                    featured = true,
                    transmission = "Automatic",
                    fuelType = "Petrol",
                    color = "Silver",
                    mileage = 35000,
                    bodyType = "Sedan",
                    registered = "Registered",
                    engineCc = 1800,
                    features = "Air Conditioner, ABS, Alloys, Airbags, Power Windows, Sunroof, Traction Control",
                    imagesString = corollaImages,
                    sellerName = "Bilal Khan",
                    sellerPhone = "03217654321",
                    viewsCount = 142
                )
            )

            listingDao.insertListing(
                Listing(
                    userId = seller2Id,
                    category = "Cars",
                    make = "Honda",
                    model = "Civic",
                    year = 2022,
                    price = 6800000.0, // 68 Lakhs
                    city = "Islamabad",
                    description = "Honda Civic Oriel 1.5 Turbo Meticulously maintained, scratchless exterior, and clean leather interior. Fitted with aftermarket side skirts. Token tax paid up-to-date.",
                    status = "Approved",
                    featured = true,
                    transmission = "Automatic",
                    fuelType = "Petrol",
                    color = "Black",
                    mileage = 18000,
                    bodyType = "Sedan",
                    registered = "Registered",
                    engineCc = 1500,
                    features = "Air Conditioner, ABS, Alloys, Airbags, Power Windows, Sunroof, Keyless Entry, Push Start",
                    imagesString = civicImages,
                    sellerName = "Fatima Malik",
                    sellerPhone = "03139876543",
                    viewsCount = 312
                )
            )

            listingDao.insertListing(
                Listing(
                    userId = adminId,
                    category = "Cars",
                    make = "Kia",
                    model = "Sportage",
                    year = 2020,
                    price = 7200000.0, // 72 Lakhs
                    city = "Karachi",
                    description = "Kia Sportage AWD. Immaculate SUV, ideal for family and offroad trips. Dual climate control, panoramic sunroof, electronically adjustable seats, and robust safety packages intact.",
                    status = "Approved",
                    featured = true,
                    transmission = "Automatic",
                    fuelType = "Petrol",
                    color = "White",
                    mileage = 45000,
                    bodyType = "SUV",
                    registered = "Registered",
                    engineCc = 2000,
                    features = "Air Conditioner, ABS, Alloys, Airbags, Power Windows, Sunroof, Cruise Control, Leather Seats, AWD",
                    imagesString = sportageImages,
                    sellerName = "Shah Raza",
                    sellerPhone = "03001234567",
                    viewsCount = 82
                )
            )

            listingDao.insertListing(
                Listing(
                    userId = seller1Id,
                    category = "Cars",
                    make = "Suzuki",
                    model = "Alto",
                    year = 2023,
                    price = 2650000.0, // 26.5 Lakhs
                    city = "Karachi",
                    description = "Suzuki Alto VXL AGS. Fuel saver model, perfect for city traffic. Features touch display screen, excellent freezing cooling air-conditioning, and smooth automatic AGS response.",
                    status = "Approved",
                    featured = false,
                    transmission = "Automatic",
                    fuelType = "Petrol",
                    color = "White",
                    mileage = 8000,
                    bodyType = "Hatchback",
                    registered = "Registered",
                    engineCc = 660,
                    features = "Air Conditioner, ABS, Power Windows, Airbags, Retrofit Navigation Screen",
                    imagesString = altoImages,
                    sellerName = "Bilal Khan",
                    sellerPhone = "03217654321",
                    viewsCount = 95
                )
            )

            // Insert Bikes
            listingDao.insertListing(
                Listing(
                    userId = seller2Id,
                    category = "Bikes",
                    make = "Yamaha",
                    model = "YBR 125",
                    year = 2022,
                    price = 410000.0, // 4.1 Lakhs
                    city = "Lahore",
                    description = "Yamaha YBR 125 Sporty design. Metallic blue color, extremely comfortable ride with self start, disk brakes, and smooth mono-shock suspension for Pakistani roads.",
                    status = "Approved",
                    featured = true,
                    transmission = "Manual",
                    fuelType = "Petrol",
                    color = "Blue",
                    mileage = 12000,
                    bodyType = "Cruiser",
                    registered = "Registered",
                    engineCc = 125,
                    features = "Alloys, Front Disk Brake, Self Start, Engine Guard",
                    imagesString = ybrImages,
                    sellerName = "Fatima Malik",
                    sellerPhone = "03139876543",
                    viewsCount = 67
                )
            )

            listingDao.insertListing(
                Listing(
                    userId = seller1Id,
                    category = "Bikes",
                    make = "Honda",
                    model = "CD 70",
                    year = 2023,
                    price = 158000.0, // 1.58 Lakhs
                    city = "Rawalpindi",
                    description = "Honda CD 70 red in absolute brand new physical form. Soundless engine, outstanding mileage of 55+ km/liter, 100% original. First tuning done at dealership recently.",
                    status = "Approved",
                    featured = false,
                    transmission = "Manual",
                    fuelType = "Petrol",
                    color = "Red",
                    mileage = 1500,
                    bodyType = "Standard",
                    registered = "Registered",
                    engineCc = 70,
                    features = "Standard Kick Start",
                    imagesString = cd70Images,
                    sellerName = "Bilal Khan",
                    sellerPhone = "03217654321",
                    viewsCount = 188
                )
            )

            // Insert Auto Parts & Accessories
            listingDao.insertListing(
                Listing(
                    userId = adminId,
                    category = "Auto Parts",
                    make = "Lenso",
                    model = "Alloy Wheels R16",
                    year = 2021,
                    price = 125000.0, // 1.25 Lakhs
                    city = "Lahore",
                    description = "Original Lenso 16 inch sport alloy wheels setup of 4. Compatible with multi-pcd hubs, highly durable and lightweight design. Visually premium finish.",
                    status = "Approved",
                    featured = false,
                    transmission = "Manual",
                    fuelType = "Petrol",
                    color = "Carbon Grey",
                    mileage = 0,
                    bodyType = "Part",
                    registered = "Unregistered",
                    engineCc = 0,
                    features = "Original centercaps included",
                    compatibility = "Toyota Corolla, Honda Civic, Suzuki Swift",
                    imagesString = alloyImages,
                    sellerName = "Shah Raza",
                    sellerPhone = "03001234567",
                    viewsCount = 42
                )
            )

            listingDao.insertListing(
                Listing(
                    userId = seller2Id,
                    category = "Accessories",
                    make = "Android Panel",
                    model = "IPS Display Player",
                    year = 2023,
                    price = 28000.0, // 28K
                    city = "Islamabad",
                    description = "9-inch high speed Android dashboard panel. Fitted with 4GB RAM + 64GB storage, IPS displays, DSP audio tuning, reverse camera input and built-in Apple CarPlay & Android Auto.",
                    status = "Approved",
                    featured = true,
                    transmission = "Manual",
                    fuelType = "Petrol",
                    color = "Black",
                    mileage = 0,
                    bodyType = "Accessory",
                    registered = "Unregistered",
                    engineCc = 0,
                    features = "Apple CarPlay, Android Auto, Wi-Fi, Bluetooth",
                    compatibility = "Toyota Corolla 2014-2021",
                    imagesString = androidPlayerImages,
                    sellerName = "Fatima Malik",
                    sellerPhone = "03139876543",
                    viewsCount = 104
                )
            )
        }
    }
}

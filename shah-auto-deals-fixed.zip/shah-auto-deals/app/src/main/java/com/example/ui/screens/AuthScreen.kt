package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel

@Composable
fun AuthScreen(
    viewModel: AppViewModel,
    onAuthSuccess: () -> Unit
) {
    var isLoginTab by remember { mutableStateOf(true) }
    val authErrorMsg by viewModel.authError.collectAsState()

    // Login fields
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var showLoginPassword by remember { mutableStateOf(false) }

    // Signup fields
    var signupName by remember { mutableStateOf("") }
    var signupEmail by remember { mutableStateOf("") }
    var signupPhone by remember { mutableStateOf("") }
    var signupCity by remember { mutableStateOf("Lahore") }
    var signupPassword by remember { mutableStateOf("") }
    var showSignupPassword by remember { mutableStateOf(false) }

    // Forgot Password OTP Dialog
    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var forgotEmailText by remember { mutableStateOf("") }
    var showOtpForm by remember { mutableStateOf(false) }
    var otpNumberText by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Corporate Logo Mark
            Icon(
                imageVector = Icons.Default.DirectionsCar,
                contentDescription = "Shah Logo",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(54.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Shah Auto Deals",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Pakistan's Trusted Auto Marketplace",
                fontSize = 11.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(24.dp))

            // TAB STATE ROW
            Row(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .height(48.dp)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(24.dp)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Login Tab
                Button(
                    onClick = { isLoginTab = true },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLoginTab) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (isLoginTab) Color.White else MaterialTheme.colorScheme.onSurface
                    ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Text("Login", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                // Signup Tab
                Button(
                    onClick = { isLoginTab = false },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!isLoginTab) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (!isLoginTab) Color.White else MaterialTheme.colorScheme.onSurface
                    ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Text("Sign Up", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (authErrorMsg != null) {
                Text(
                    text = authErrorMsg ?: "",
                    color = Color.Red,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            // FORMS COLUMN
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (isLoginTab) {
                        // 1. LOGIN SCREEN
                        Text("Welcome Back", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = loginEmail,
                            onValueChange = { loginEmail = it },
                            label = { Text("Email address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = "Email") },
                            modifier = Modifier.fillMaxWidth().testTag("username_input"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it },
                            label = { Text("Password") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "Password") },
                            trailingIcon = {
                                IconButton(onClick = { showLoginPassword = !showLoginPassword }) {
                                    Icon(
                                        imageVector = if (showLoginPassword) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Show Password"
                                    )
                                }
                            },
                            visualTransformation = if (showLoginPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Forgot password trigger
                        Text(
                            text = "Forgot Password / Verify OTP?",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.End)
                                .clickable { showForgotPasswordDialog = true }
                                .padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.login(loginEmail, loginPassword, onAuthSuccess)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("login_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Log In", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                    } else {
                        // 2. SIGN UP SCREEN
                        Text("Create An Account", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = signupName,
                            onValueChange = { signupName = it },
                            label = { Text("Full Name") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = "Person") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = signupEmail,
                            onValueChange = { signupEmail = it },
                            label = { Text("Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = "Email") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = signupPhone,
                            onValueChange = { signupPhone = it },
                            label = { Text("Phone Number (e.g. 03211234567)") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = "Phone") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // City selector field
                        Text("Select City", fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad").forEach { city ->
                                val isSel = city == signupCity
                                FilterChip(selected = isSel, onClick = { signupCity = city }, label = { Text(city) })
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = signupPassword,
                            onValueChange = { signupPassword = it },
                            label = { Text("Password") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "Password") },
                            trailingIcon = {
                                IconButton(onClick = { showSignupPassword = !showSignupPassword }) {
                                    Icon(
                                        imageVector = if (showSignupPassword) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Show Password"
                                    )
                                }
                            },
                            visualTransformation = if (showSignupPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.signup(signupName, signupEmail, signupPhone, signupCity, signupPassword, onAuthSuccess)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Sign Up", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Simulated Social Google Login Button
            Text("OR", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedCard(
                onClick = {
                    // Prepopulate and trigger successful Google simulation login
                    viewModel.login("bilal@yahoo.com", "user123", onAuthSuccess)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("google_login_card"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.AccountCircle, contentDescription = "Google Play", tint = Color.Red, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Continue with Google", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // OTP / FORGOT PASSWORD MODAL WINDOW
        if (showForgotPasswordDialog) {
            AlertDialog(
                onDismissRequest = {
                    showForgotPasswordDialog = false
                    showOtpForm = false
                    forgotEmailText = ""
                },
                title = { Text(if (showOtpForm) "Enter Security OTP Code" else "Forgot Password", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        if (!showOtpForm) {
                            Text("Enter your registered email. We will send an SMS OTP verification pin to your active seller phone number on file.", fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = forgotEmailText,
                                onValueChange = { forgotEmailText = it },
                                placeholder = { Text("e.g. bilal@yahoo.com") },
                                leadingIcon = { Icon(Icons.Outlined.MailOutline, contentDescription = "") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            Text("A 4-digit SMS OTP reset code was dispatched to your phone. Check messages.", fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = otpNumberText,
                                onValueChange = { otpNumberText = it },
                                placeholder = { Text("Enter 4-digit code (e.g., 9482)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (!showOtpForm) {
                                if (forgotEmailText.isNotBlank()) {
                                    showOtpForm = true
                                    viewModel.triggerToast("SMS OTP code dispatched successfully!")
                                } else {
                                    viewModel.triggerToast("Please write email details.")
                                }
                            } else {
                                if (otpNumberText.isNotBlank()) {
                                    viewModel.triggerToast("Phone verified! Assigned default user credential: user123")
                                    // Log them in immediately with default demo
                                    viewModel.login("bilal@yahoo.com", "user123", onAuthSuccess)
                                    showForgotPasswordDialog = false
                                    showOtpForm = false
                                } else {
                                    viewModel.triggerToast("Please provide the OTP code.")
                                }
                            }
                        }
                    ) {
                        Text(if (showOtpForm) "Verify & Access" else "Send SMS OTP Code")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showForgotPasswordDialog = false
                        showOtpForm = false
                    }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

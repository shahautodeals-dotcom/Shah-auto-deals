package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Listing
import com.example.ui.theme.ShahOrange
import java.text.DecimalFormat

/**
 * Robust utility for human-readable PKR pricing formatter
 * Example: 4,500,000.0 becomes "PKR 45.00 Lacs"
 * Example: 25,000,000.0 becomes "PKR 2.50 Crore"
 */
fun formatPricePkr(price: Double): String {
    return when {
        price >= 10_000_000 -> {
            val crore = price / 10_000_000
            String.format("PKR %.2f Crore", crore)
        }
        price >= 100_000 -> {
            val lac = price / 100_000
            String.format("PKR %.2f Lacs", lac)
        }
        else -> {
            val formatter = DecimalFormat("#,###")
            "PKR " + formatter.format(price)
        }
    }
}

/**
 * Reusable layout Row for Listing representation (List View)
 */
@Composable
fun ListingRowItem(
    listing: Listing,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFECEFF3)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Image Section
            Box(
                modifier = Modifier
                    .size(95.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFF1F5F9))
            ) {
                val thumbnailUrl = listing.imagesList.firstOrNull() ?: "https://images.unsplash.com/photo-1623998021451-31d864115160?w=300"
                AsyncImage(
                    model = thumbnailUrl,
                    contentDescription = "${listing.make} ${listing.model}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Optional Banner Badge
                if (listing.featured) {
                    Box(
                        modifier = Modifier
                            .padding(4.dp)
                            .background(ShahOrange, RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Text(
                            "FEATURED", 
                            color = Color.White, 
                            fontSize = 8.sp, 
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Right Info Details Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${listing.make} ${listing.model} ${listing.year}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    
                    if (listing.id % 2 == 1) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFE3EDF7), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "CERTIFIED", 
                                color = Color(0xFF1B3F6B), 
                                fontSize = 8.sp, 
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))
                
                Text(
                    text = formatPricePkr(listing.price),
                    color = Color(0xFF1B3F6B),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn, 
                        contentDescription = "Location", 
                        tint = Color.Gray, 
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = listing.city,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = "${listing.year} • 54,000 km • ${listing.fuelType} • ${listing.transmission}",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

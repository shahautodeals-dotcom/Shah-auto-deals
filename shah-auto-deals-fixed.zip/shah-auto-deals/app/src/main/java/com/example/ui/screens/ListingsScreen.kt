package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Listing
import com.example.ui.theme.ShahOrange
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ListingsScreen(
    viewModel: AppViewModel,
    onNavigateToDetail: (Int) -> Unit
) {
    val listings by viewModel.listings.collectAsState()
    val activeCategory by viewModel.selectedCategory.collectAsState()
    val viewAsGrid by viewModel.gridMode.collectAsState()
    val sortByActive by viewModel.sortBy.collectAsState()
    val searchQueryText by viewModel.searchQuery.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }

    // Dropdowns and lists for filters
    val categories = listOf("All", "Cars", "Bikes", "Auto Parts", "Accessories")
    val sorts = listOf("Latest", "Price Low-High", "Price High-Low", "Most Viewed")

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                // Secondary search and filter summary row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQueryText,
                        onValueChange = { viewModel.searchQuery.value = it },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        placeholder = { Text("Search make, model, parts...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(20.dp)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.background,
                            unfocusedContainerColor = MaterialTheme.colorScheme.background
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Advanced Filter Toggle Button
                    IconButton(
                        onClick = { showFilterSheet = true },
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("filter_sidebar_toggle")
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(22.dp))
                    ) {
                        Icon(Icons.Default.FilterList, contentDescription = "Filter", tint = MaterialTheme.colorScheme.primary)
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Grid/List view toggle
                    IconButton(
                        onClick = { viewModel.gridMode.value = !viewAsGrid },
                        modifier = Modifier
                            .size(44.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(22.dp))
                    ) {
                        Icon(
                            imageVector = if (viewAsGrid) Icons.Default.ViewList else Icons.Default.GridView,
                            contentDescription = "Toggle Grid",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Horizontal scrollable Category Chips
                ScrollableRowChips(
                    items = categories,
                    selectedItem = activeCategory ?: "All",
                    onSelected = {
                        viewModel.resetFilters()
                        viewModel.selectedCategory.value = if (it == "All") null else it
                    }
                )

                Divider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Results and sorting summary row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Results (${listings.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    // Sort selector dropdown
                    var sortExpanded by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { sortExpanded = true }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Sort: $sortByActive", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Sort dropdown")
                            }
                        }
                        DropdownMenu(
                            expanded = sortExpanded,
                            onDismissRequest = { sortExpanded = false }
                        ) {
                            sorts.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s) },
                                    onClick = {
                                        viewModel.sortBy.value = s
                                        sortExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Grid or List listing view
                if (listings.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SearchOff, contentDescription = "Empty", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Vehicles found matching criteria.", fontWeight = FontWeight.SemiBold, color = Color.Gray)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = { viewModel.resetFilters() }) {
                                Text("Clear All Filters")
                            }
                        }
                    }
                } else if (viewAsGrid) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(listings) { ad ->
                            GridAdCard(ad = ad, onClick = { onNavigateToDetail(ad.id) })
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(listings) { ad ->
                            ListAdCard(ad = ad, onClick = { onNavigateToDetail(ad.id) })
                        }
                    }
                }
            }

            // FILTER POPUP DRAWER (Modal Bottom Sheet)
            if (showFilterSheet) {
                FilterSelectorBottomSheet(
                    viewModel = viewModel,
                    activeCategory = activeCategory,
                    onDismiss = { showFilterSheet = false }
                )
            }
        }
    }
}

@Composable
fun ScrollableRowChips(
    items: List<String>,
    selectedItem: String,
    onSelected: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { label ->
            val isSelected = label == selectedItem
            FilterChip(
                selected = isSelected,
                onClick = { onSelected(label) },
                label = { Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

@Composable
fun GridAdCard(ad: Listing, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box {
                val firstImage = ad.imagesList.firstOrNull() ?: ""
                AsyncImage(
                    model = firstImage,
                    contentDescription = "${ad.make} ${ad.model}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(115.dp)
                )
                if (ad.featured) {
                    Box(
                        modifier = Modifier
                            .padding(6.dp)
                            .background(ShahOrange, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Text("FEATURED", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "${ad.make} ${ad.model}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = ad.year.toString(),
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formatPricePkr(ad.price),
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = "City", tint = Color.LightGray, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = ad.city,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ListAdCard(ad: Listing, onClick: () -> Unit) {
    ListingRowItem(listing = ad, onClick = onClick)
}

// Bottom Sheet carrying advanced inputs
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FilterSelectorBottomSheet(
    viewModel: AppViewModel,
    activeCategory: String?,
    onDismiss: () -> Unit
) {
    // Current filter states
    val filterMake by viewModel.selectedMake.collectAsState()
    val filterModel by viewModel.selectedModel.collectAsState()
    val filterCity by viewModel.selectedCity.collectAsState()
    val filterTransmission by viewModel.selectedTransmission.collectAsState()
    val filterFuelType by viewModel.selectedFuelType.collectAsState()
    val filterBodyType by viewModel.bodyType.collectAsState()
    val filterRegistered by viewModel.registered.collectAsState()

    val minYearVal by viewModel.minYear.collectAsState()
    val maxYearVal by viewModel.maxYear.collectAsState()
    val minPriceVal by viewModel.minPrice.collectAsState()
    val maxPriceVal by viewModel.maxPrice.collectAsState()

    val engineCcMinVal by viewModel.engineCcMin.collectAsState()
    val engineCcMaxVal by viewModel.engineCcMax.collectAsState()

    // Local string buffer fields
    var makeText by remember { mutableStateOf(filterMake ?: "") }
    var modelText by remember { mutableStateOf(filterModel ?: "") }
    var cityText by remember { mutableStateOf(filterCity ?: "") }
    var transmissionText by remember { mutableStateOf(filterTransmission ?: "") }
    var fuelTypeText by remember { mutableStateOf(filterFuelType ?: "") }
    var bodyTypeText by remember { mutableStateOf(filterBodyType ?: "") }
    var registeredText by remember { mutableStateOf(filterRegistered ?: "") }

    var minYearText by remember { mutableStateOf(minYearVal?.toString() ?: "") }
    var maxYearText by remember { mutableStateOf(maxYearVal?.toString() ?: "") }
    var minPriceText by remember { mutableStateOf(minPriceVal?.toString() ?: "") }
    var maxPriceText by remember { mutableStateOf(maxPriceVal?.toString() ?: "") }

    var engineCcMinText by remember { mutableStateOf(engineCcMinVal?.toString() ?: "") }
    var engineCcMaxText by remember { mutableStateOf(engineCcMaxVal?.toString() ?: "") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        modifier = Modifier.fillMaxHeight(0.9f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Advanced Filters", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = {
                    viewModel.resetFilters()
                    onDismiss()
                }) {
                    Text("Reset All", color = Color.Red)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Brand / Make Filter
            val isBike = activeCategory == "Bikes"
            val isParts = activeCategory == "Auto Parts" || activeCategory == "Accessories"

            Text(if (isBike) "Bike Brand" else if (isParts) "Brand/Compat" else "Make / Brand", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            val makes = if (isBike) {
                listOf("Honda", "Yamaha", "Suzuki", "United", "Ravi")
            } else {
                listOf("Toyota", "Honda", "Suzuki", "Kia", "Hyundai", "Daihatsu", "Nissan", "Mitsubishi")
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                makes.forEach { make ->
                    val isSel = makeText.equals(make, ignoreCase = true)
                    ElevatedFilterChip(
                        selected = isSel,
                        onClick = { makeText = if (isSel) "" else make },
                        label = { Text(make, fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Model Input
            Text("Model / Version", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = modelText,
                onValueChange = { modelText = it },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                placeholder = { Text("e.g. Corolla, Civic, YBR") },
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Local Pakistani Cities
            Text("City Location", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            val cities = listOf("Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar")
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                cities.forEach { city ->
                    val isSel = cityText.equals(city, ignoreCase = true)
                    ElevatedFilterChip(
                        selected = isSel,
                        onClick = { cityText = if (isSel) "" else city },
                        label = { Text(city, fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Price Range
            Text("Price Range (PKR)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = minPriceText,
                    onValueChange = { minPriceText = it },
                    label = { Text("From") },
                    modifier = Modifier.weight(1f).height(55.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedTextField(
                    value = maxPriceText,
                    onValueChange = { maxPriceText = it },
                    label = { Text("To") },
                    modifier = Modifier.weight(1f).height(55.dp),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Year Range
            Text("Year Range", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = minYearText,
                    onValueChange = { minYearText = it },
                    label = { Text("From") },
                    placeholder = { Text("2000") },
                    modifier = Modifier.weight(1f).height(55.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedTextField(
                    value = maxYearText,
                    onValueChange = { maxYearText = it },
                    label = { Text("To") },
                    placeholder = { Text("2024") },
                    modifier = Modifier.weight(1f).height(55.dp),
                    singleLine = true
                )
            }

            // Bike specific filters (Engine CC size)
            if (activeCategory == "Bikes") {
                Spacer(modifier = Modifier.height(14.dp))
                Text("Engine Size (CC)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = engineCcMinText,
                        onValueChange = { engineCcMinText = it },
                        label = { Text("Min cc") },
                        placeholder = { Text("70") },
                        modifier = Modifier.weight(1f).height(55.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    OutlinedTextField(
                        value = engineCcMaxText,
                        onValueChange = { engineCcMaxText = it },
                        label = { Text("Max cc") },
                        placeholder = { Text("250") },
                        modifier = Modifier.weight(1f).height(55.dp),
                        singleLine = true
                    )
                }
            }

            if (activeCategory == "Cars") {
                Spacer(modifier = Modifier.height(14.dp))

                // Cars features (Transmission, Fuel Type, Body Type, Registered status)
                Text("Transmission", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Automatic", "Manual").forEach { trans ->
                        val isSel = transmissionText == trans
                        FilterChip(
                            selected = isSel,
                            onClick = { transmissionText = if (isSel) "" else trans },
                            label = { Text(trans) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Fuel Type", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Petrol", "Diesel", "Hybrid", "Electric").forEach { fuel ->
                        val isSel = fuelTypeText == fuel
                        FilterChip(
                            selected = isSel,
                            onClick = { fuelTypeText = if (isSel) "" else fuel },
                            label = { Text(fuel) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Body Type", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Sedan", "SUV", "Hatchback", "Van", "Pickup", "Coupe").forEach { body ->
                        val isSel = bodyTypeText == body
                        FilterChip(
                            selected = isSel,
                            onClick = { bodyTypeText = if (isSel) "" else body },
                            label = { Text(body) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Registration Status", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Registered", "Unregistered").forEach { reg ->
                        val isSel = registeredText == reg
                        FilterChip(
                            selected = isSel,
                            onClick = { registeredText = if (isSel) "" else reg },
                            label = { Text(reg) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Trigger Search Actions
            Button(
                onClick = {
                    viewModel.selectedMake.value = makeText
                    viewModel.selectedModel.value = modelText
                    viewModel.selectedCity.value = cityText
                    viewModel.selectedTransmission.value = transmissionText
                    viewModel.selectedFuelType.value = fuelTypeText
                    viewModel.bodyType.value = bodyTypeText
                    viewModel.registered.value = registeredText

                    viewModel.minYear.value = minYearText.toIntOrNull()
                    viewModel.maxYear.value = maxYearText.toIntOrNull()
                    viewModel.minPrice.value = minPriceText.toDoubleOrNull()
                    viewModel.maxPrice.value = maxPriceText.toDoubleOrNull()

                    viewModel.engineCcMin.value = engineCcMinText.toIntOrNull()
                    viewModel.engineCcMax.value = engineCcMaxText.toIntOrNull()

                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_filter_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Apply Filters", fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

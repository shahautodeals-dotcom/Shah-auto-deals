package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class Repository(private val db: AppDatabase) {

    private val userDao = db.userDao()
    private val listingDao = db.listingDao()
    private val favoriteDao = db.favoriteDao()
    private val messageDao = db.messageDao()
    private val reportDao = db.reportDao()

    // Session Management State
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    suspend fun login(email: String, passwordHash: String): Boolean {
        val user = userDao.getUserByEmail(email)
        return if (user != null && user.passwordHash == passwordHash) {
            _currentUser.value = user
            true
        } else {
            false
        }
    }

    suspend fun signup(name: String, email: String, phone: String, city: String, passwordHash: String): Boolean {
        val existing = userDao.getUserByEmail(email)
        if (existing != null) return false

        val user = User(
            name = name,
            email = email,
            phone = phone,
            city = city,
            passwordHash = passwordHash
        )
        val id = userDao.insertUser(user)
        _currentUser.value = user.copy(id = id.toInt())
        return true
    }

    suspend fun logout() {
        _currentUser.value = null
    }

    suspend fun updateUserProfile(user: User) {
        userDao.updateUser(user)
        if (_currentUser.value?.id == user.id) {
            _currentUser.value = user
        }
    }

    suspend fun getUserById(userId: Int): User? {
        return userDao.getUserById(userId)
    }

    // Listings Flow operations
    fun getAllListings(): Flow<List<Listing>> = listingDao.getAllListingsFlow()

    fun getFilteredListings(
        category: String?,
        make: String? = null,
        model: String? = null,
        minPrice: Double? = null,
        maxPrice: Double? = null,
        city: String? = null,
        transmission: String? = null,
        fuelType: String? = null,
        minYear: Int? = null,
        maxYear: Int? = null,
        bodyType: String? = null,
        registered: String? = null,
        searchQuery: String? = null,
        sortBy: String? = "Latest",
        engineCcMin: Int? = null,
        engineCcMax: Int? = null
    ): Flow<List<Listing>> {
        return listingDao.getAllListingsFlow().map { listings ->
            // Filter by Admin approval + Custom criteria
            // (Exclude listings set to Rejected status, display active ones)
            var filtered = listings.filter { listing ->
                val approved = listing.status == "Active" || listing.status == "Approved"
                
                approved &&
                (category == null || listing.category.equals(category, ignoreCase = true)) &&
                (make == null || make.isBlank() || listing.make.equals(make, ignoreCase = true)) &&
                (model == null || model.isBlank() || listing.model.contains(model, ignoreCase = true)) &&
                (minPrice == null || listing.price >= minPrice) &&
                (maxPrice == null || listing.price <= maxPrice) &&
                (city == null || city.isBlank() || listing.city.equals(city, ignoreCase = true)) &&
                (transmission == null || transmission.isBlank() || listing.transmission.equals(transmission, ignoreCase = true)) &&
                (fuelType == null || fuelType.isBlank() || listing.fuelType.equals(fuelType, ignoreCase = true)) &&
                (minYear == null || listing.year >= minYear) &&
                (maxYear == null || listing.year <= maxYear) &&
                (bodyType == null || bodyType.isBlank() || listing.bodyType.equals(bodyType, ignoreCase = true)) &&
                (registered == null || registered.isBlank() || listing.registered.equals(registered, ignoreCase = true)) &&
                (engineCcMin == null || listing.engineCc >= engineCcMin) &&
                (engineCcMax == null || listing.engineCc <= engineCcMax) &&
                (searchQuery == null || searchQuery.isBlank() || 
                    listing.make.contains(searchQuery, ignoreCase = true) || 
                    listing.model.contains(searchQuery, ignoreCase = true) || 
                    listing.description.contains(searchQuery, ignoreCase = true) || 
                    listing.city.contains(searchQuery, ignoreCase = true))
            }

            // Apply Sort
            filtered = when (sortBy) {
                "Price Low-High" -> filtered.sortedBy { it.price }
                "Price High-Low" -> filtered.sortedByDescending { it.price }
                "Most Viewed" -> filtered.sortedByDescending { it.viewsCount }
                else -> filtered.sortedByDescending { it.createdAt } // "Latest"
            }

            filtered
        }
    }

    suspend fun getListingById(id: Int): Listing? {
        return listingDao.getListingById(id)
    }

    suspend fun incrementViews(listingId: Int) {
        listingDao.incrementViews(listingId)
    }

    suspend fun insertListing(listing: Listing): Int {
        return listingDao.insertListing(listing).toInt()
    }

    suspend fun updateListing(listing: Listing) {
        listingDao.updateListing(listing)
    }

    suspend fun deleteListing(listing: Listing) {
        listingDao.deleteListing(listing)
    }

    fun getMyListingsFlow(userId: Int): Flow<List<Listing>> {
        return listingDao.getListingsByUserIdFlow(userId)
    }

    // Favorites
    fun getFavoritesFlow(userId: Int): Flow<List<Listing>> {
        return combine(
            favoriteDao.getFavoritesForUserFlow(userId),
            listingDao.getAllListingsFlow()
        ) { favorites, listings ->
            val favIds = favorites.map { it.listingId }.toSet()
            listings.filter { it.id in favIds }
        }
    }

    suspend fun isFavorite(userId: Int, listingId: Int): Boolean {
        return favoriteDao.getFavorite(userId, listingId) != null
    }

    suspend fun toggleFavorite(userId: Int, listingId: Int) {
        val fav = favoriteDao.getFavorite(userId, listingId)
        if (fav != null) {
            favoriteDao.deleteFavorite(fav)
        } else {
            favoriteDao.insertFavorite(Favorite(userId = userId, listingId = listingId))
        }
    }

    // Messages
    fun getMessagesFlow(userId: Int): Flow<List<Message>> {
        return messageDao.getMessagesForUserFlow(userId)
    }

    suspend fun sendMessage(senderId: Int, receiverId: Int, listingId: Int, messageText: String, senderName: String, listingTitle: String) {
        val message = Message(
            senderId = senderId,
            receiverId = receiverId,
            listingId = listingId,
            message = messageText,
            senderName = senderName,
            listingTitle = listingTitle
        )
        messageDao.insertMessage(message)
    }

    // Reports
    fun getAllReportsFlow(): Flow<List<Report>> = reportDao.getAllReportsFlow()

    suspend fun submitReport(userId: Int, listingId: Int, reason: String, listingTitle: String, reporterName: String) {
        val report = Report(
            userId = userId,
            listingId = listingId,
            reason = reason,
            listingTitle = listingTitle,
            reporterName = reporterName
        )
        reportDao.insertReport(report)
    }

    suspend fun updateReport(report: Report) {
        reportDao.updateReport(report)
    }

    // Admin Operations
    fun getAllUsersFlow(): Flow<List<User>> = userDao.getAllUsersFlow()
    
    fun getAllAdminListingsFlow(): Flow<List<Listing>> = listingDao.getAllListingsFlow()

    suspend fun adminApproveListing(listing: Listing) {
        listingDao.updateListing(listing.copy(status = "Approved"))
    }

    suspend fun adminRejectListing(listing: Listing) {
        listingDao.updateListing(listing.copy(status = "Rejected"))
    }

    suspend fun deleteUser(user: User) {
        userDao.deleteUser(user)
    }
}
